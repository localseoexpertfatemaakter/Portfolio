# Local SEO Portfolio Website

## Overview

This is a professional SEO expert portfolio website for Fatema Akter built with pure HTML, CSS, and JavaScript (no frameworks). The application showcases SEO services across three distinct regions (US, UK, and Italy) with dedicated sections for each market. The site features a comprehensive service showcase, client testimonials, portfolio examples, WhatsApp integration, and contact forms designed to convert visitors into clients.

## Recent Changes (August 18, 2025)

- ✅ Complete conversion from React/TypeScript to vanilla HTML, CSS, JavaScript
- ✅ Implemented responsive single-page application with all essential sections
- ✅ Added WhatsApp popup with tooltip functionality for lead generation
- ✅ Created scroll-to-top button with smooth animations
- ✅ Built comprehensive contact form with validation
- ✅ Integrated region-specific content for US, UK, and Italy markets
- ✅ Added SEO-optimized meta tags and Open Graph integration
- ✅ Implemented mobile-responsive design with hamburger menu
- ✅ Created newsletter signup functionality in footer
- ✅ Added notification system for user feedback

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Architecture
- **Frontend**: Pure HTML5, CSS3, and JavaScript (ES6+) - no frameworks or libraries
- **Styling**: Custom CSS with CSS variables and responsive design principles
- **Icons**: Font Awesome CDN for consistent iconography
- **Fonts**: Google Fonts (Poppins for headings, Roboto for body text)
- **Interactions**: Vanilla JavaScript for all functionality including form handling, navigation, and animations
- **Structure**: Single-page application with smooth scroll navigation between sections

### Component Organization
- **Layout Components**: Header with navigation and region dropdowns, Footer with newsletter signup
- **Page Components**: Home, About, Services, Portfolio, Testimonials, Contact, and region-specific pages
- **Common Components**: WhatsApp popup for lead generation, scroll-to-top functionality
- **UI Components**: Comprehensive design system based on shadcn/ui for consistency

### Design System
- **Typography**: Poppins for headings, Roboto for body text
- **Color Scheme**: Professional blue primary (#208BF0), green secondary (#22C55E), yellow accent (#F59E0B)
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Accessibility**: ARIA labels, semantic HTML, keyboard navigation support

### SEO Optimization Features
- **Meta Tags**: Comprehensive OpenGraph and Twitter Card metadata
- **Structured Navigation**: Clear hierarchy for search engine crawling
- **Performance**: Optimized images, lazy loading, and efficient bundling
- **Regional Content**: Dedicated pages for US, UK, and Italy markets with localized content

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Router (Wouter)
- **TypeScript**: Full TypeScript support with strict configuration
- **Build Tools**: Vite for development and production builds, ESBuild for server bundling

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with PostCSS and Autoprefixer
- **Radix UI**: Accessible component primitives (@radix-ui/react-*)
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Utility for component variant management

### Backend and Database
- **Neon Database**: PostgreSQL serverless database (@neondatabase/serverless)
- **Drizzle ORM**: Type-safe ORM with PostgreSQL dialect
- **Express.js**: Web framework for API endpoints
- **Connect PG Simple**: PostgreSQL session store for Express

### Development and Validation
- **Zod**: Schema validation for forms and API data
- **React Hook Form**: Form handling with validation integration
- **TanStack Query**: Server state management and caching
- **Date-fns**: Date manipulation utilities

### External Services Integration
- **Font Integration**: Google Fonts (Poppins, Roboto)
- **Icon Libraries**: Font Awesome for social icons and UI elements
- **WhatsApp API**: Direct messaging integration for lead generation
- **Email Services**: Newsletter signup functionality (implementation ready)

### Development Tools
- **Replit Integration**: Cartographer plugin for Replit development environment
- **Runtime Error Handling**: Vite plugin for better error visualization
- **TypeScript Configuration**: Strict type checking with modern ES modules