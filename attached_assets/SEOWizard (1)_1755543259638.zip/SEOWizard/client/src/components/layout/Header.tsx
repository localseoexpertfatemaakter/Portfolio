import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Header() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navigation = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "Services", href: "/services" },
    { name: "Portfolio", href: "/portfolio" },
    { name: "Testimonials", href: "/testimonials" },
    { name: "Contact", href: "/contact" },
  ];

  const regions = [
    { name: "🇺🇸 United States", href: "/us-region" },
    { name: "🇬🇧 United Kingdom", href: "/uk-region" },
    { name: "🇮🇹 Italy", href: "/italy-region" },
  ];

  return (
    <header className="bg-white shadow-lg fixed w-full top-0 z-50" data-testid="header-main">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="font-poppins font-bold text-2xl text-seo-primary" data-testid="link-home">
            Fatema Akter
            <span className="block text-sm font-normal text-gray-600">SEO Expert</span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden lg:flex space-x-8">
            {navigation.map((item) => (
              <Link 
                key={item.name} 
                href={item.href}
                className={`font-medium transition-colors ${
                  location === item.href 
                    ? "text-seo-primary" 
                    : "text-gray-700 hover:text-seo-primary"
                }`}
                data-testid={`link-${item.name.toLowerCase()}`}
              >
                {item.name}
              </Link>
            ))}
            <div className="relative group">
              <button className="text-gray-700 hover:text-seo-primary transition-colors font-medium flex items-center" data-testid="button-regions">
                Regions <i className="fas fa-chevron-down ml-1 text-xs"></i>
              </button>
              <div className="absolute top-full left-0 mt-2 w-48 bg-white shadow-lg rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                {regions.map((region) => (
                  <Link 
                    key={region.name} 
                    href={region.href}
                    className="block px-4 py-3 text-gray-700 hover:bg-gray-50 hover:text-seo-primary"
                    data-testid={`link-region-${region.href.replace('/', '')}`}
                  >
                    {region.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>
          
          {/* CTA Button */}
          <div className="hidden lg:block">
            <Link href="/contact">
              <Button className="bg-seo-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-600 transition-colors" data-testid="button-free-audit">
                Free SEO Audit
              </Button>
            </Link>
          </div>
          
          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" className="lg:hidden" data-testid="button-mobile-menu">
                <i className="fas fa-bars text-xl"></i>
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col space-y-4 mt-8">
                {navigation.map((item) => (
                  <Link 
                    key={item.name} 
                    href={item.href}
                    onClick={() => setIsOpen(false)}
                    className="block py-2 text-gray-700 hover:text-seo-primary"
                    data-testid={`link-mobile-${item.name.toLowerCase()}`}
                  >
                    {item.name}
                  </Link>
                ))}
                <div className="border-t pt-4">
                  <p className="text-sm font-semibold text-gray-900 mb-2">Regions</p>
                  {regions.map((region) => (
                    <Link 
                      key={region.name} 
                      href={region.href}
                      onClick={() => setIsOpen(false)}
                      className="block py-2 text-gray-700 hover:text-seo-primary"
                      data-testid={`link-mobile-region-${region.href.replace('/', '')}`}
                    >
                      {region.name}
                    </Link>
                  ))}
                </div>
                <Link href="/contact" onClick={() => setIsOpen(false)}>
                  <Button className="w-full bg-seo-primary text-white rounded-lg" data-testid="button-mobile-free-audit">
                    Free SEO Audit
                  </Button>
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}
