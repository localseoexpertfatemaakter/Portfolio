import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function Footer() {
  const [email, setEmail] = useState("");

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter signup
    console.log("Newsletter signup:", email);
    setEmail("");
  };

  return (
    <footer className="bg-gray-900 text-white py-16" data-testid="footer-main">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Brand Column */}
          <div>
            <div className="font-poppins font-bold text-2xl mb-4" data-testid="text-brand-name">
              Fatema Akter
              <span className="block text-sm font-normal text-gray-400">SEO Expert</span>
            </div>
            <p className="text-gray-400 mb-6" data-testid="text-brand-description">
              Helping businesses dominate local search results across the US, UK, and Italy with proven SEO strategies.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-seo-primary text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors" data-testid="link-social-linkedin">
                <i className="fab fa-linkedin"></i>
              </a>
              <a href="#" className="bg-seo-primary text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors" data-testid="link-social-twitter">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="bg-seo-primary text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors" data-testid="link-social-facebook">
                <i className="fab fa-facebook"></i>
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-6">Quick Links</h3>
            <div className="space-y-3">
              <Link href="/" className="block text-gray-400 hover:text-white transition-colors" data-testid="link-footer-home">Home</Link>
              <Link href="/about" className="block text-gray-400 hover:text-white transition-colors" data-testid="link-footer-about">About</Link>
              <Link href="/services" className="block text-gray-400 hover:text-white transition-colors" data-testid="link-footer-services">Services</Link>
              <Link href="/portfolio" className="block text-gray-400 hover:text-white transition-colors" data-testid="link-footer-portfolio">Portfolio</Link>
              <Link href="/contact" className="block text-gray-400 hover:text-white transition-colors" data-testid="link-footer-contact">Contact</Link>
            </div>
          </div>
          
          {/* Regions */}
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-6">Regions</h3>
            <div className="space-y-3">
              <Link href="/us-region" className="block text-gray-400 hover:text-white transition-colors" data-testid="link-footer-us">🇺🇸 United States</Link>
              <Link href="/uk-region" className="block text-gray-400 hover:text-white transition-colors" data-testid="link-footer-uk">🇬🇧 United Kingdom</Link>
              <Link href="/italy-region" className="block text-gray-400 hover:text-white transition-colors" data-testid="link-footer-italy">🇮🇹 Italy</Link>
            </div>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-6">Stay Updated</h3>
            <p className="text-gray-400 mb-4">Get the latest SEO tips and insights.</p>
            <form onSubmit={handleNewsletterSubmit} className="flex">
              <Input 
                type="email" 
                placeholder="Enter your email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 text-gray-900 rounded-l-lg rounded-r-none focus:outline-none"
                data-testid="input-newsletter-email"
                required
              />
              <Button 
                type="submit"
                className="bg-seo-primary text-white px-6 py-3 rounded-r-lg rounded-l-none hover:bg-blue-600 transition-colors"
                data-testid="button-newsletter-submit"
              >
                <i className="fas fa-paper-plane"></i>
              </Button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8 text-center">
          <p className="text-gray-400" data-testid="text-copyright">
            © 2024 Fatema Akter. All rights reserved. | Professional SEO Services for US, UK & Italy
          </p>
        </div>
      </div>
    </footer>
  );
}
