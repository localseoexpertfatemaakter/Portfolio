import { useState, useEffect } from "react";

export default function WhatsAppPopup() {
  const [showTooltip, setShowTooltip] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollButton(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const openWhatsApp = () => {
    const phoneNumber = '8801516089599';
    const message = 'Hi Fatema! I\'m interested in your SEO services. Can we discuss my requirements?';
    const whatsappURL = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappURL, '_blank');
  };

  const shareWebsite = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Fatema Akter - SEO Expert',
        text: 'Check out this amazing SEO expert services!',
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Website link copied to clipboard!');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3" data-testid="whatsapp-popup">
      {/* Scroll to Top Button */}
      {showScrollButton && (
        <button 
          className="bg-blue-500 text-white w-12 h-12 rounded-full shadow-lg hover:bg-blue-600 transition-all duration-300 flex items-center justify-center"
          onClick={scrollToTop}
          data-testid="button-scroll-top"
        >
          <i className="fas fa-arrow-up text-lg"></i>
        </button>
      )}

      {/* Share Button */}
      <button 
        className="bg-purple-500 text-white w-12 h-12 rounded-full shadow-lg hover:bg-purple-600 transition-colors flex items-center justify-center"
        onClick={shareWebsite}
        data-testid="button-share"
      >
        <i className="fas fa-share-alt text-lg"></i>
      </button>

      {/* WhatsApp Button */}
      <button 
        className="bg-green-500 text-white w-16 h-16 rounded-full shadow-lg hover:bg-green-600 transition-colors flex items-center justify-center"
        onClick={openWhatsApp}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        data-testid="button-whatsapp"
      >
        <i className="fab fa-whatsapp text-2xl"></i>
      </button>
      
      {showTooltip && (
        <div className="absolute bottom-20 right-0 bg-white p-4 rounded-lg shadow-lg w-64 animate-in slide-in-from-bottom-2" data-testid="whatsapp-tooltip">
          <div className="font-semibold mb-2">Need Quick Help?</div>
          <div className="text-sm text-gray-600 mb-3">Chat with me on WhatsApp for instant SEO consultation!</div>
          <div className="flex gap-2">
            <button 
              onClick={openWhatsApp} 
              className="bg-green-500 text-white px-3 py-2 rounded flex-1 hover:bg-green-600 transition-colors text-sm"
              data-testid="button-start-chat"
            >
              <i className="fab fa-whatsapp mr-1"></i>
              Chat
            </button>
            <button 
              onClick={shareWebsite} 
              className="bg-purple-500 text-white px-3 py-2 rounded flex-1 hover:bg-purple-600 transition-colors text-sm"
              data-testid="button-share-tooltip"
            >
              <i className="fas fa-share mr-1"></i>
              Share
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
