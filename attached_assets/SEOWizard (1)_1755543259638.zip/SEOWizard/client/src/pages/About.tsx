import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 gradient-bg text-white" data-testid="section-about-hero">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6" data-testid="text-about-hero-title">
            About <span className="text-yellow-300">Fatema Akter</span>
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8" data-testid="text-about-hero-subtitle">
            Your trusted local SEO consultant with proven expertise across US, UK, and Italy markets
          </p>
        </div>
      </section>

      {/* Personal Bio Section */}
      <section className="py-20 bg-white" data-testid="section-personal-bio">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://i.ibb.co.com/RTBqKywZ/Fatema-akter-1.jpg" 
                alt="Fatema Akter - Professional SEO Expert"
                className="rounded-xl shadow-lg w-full"
                data-testid="img-about-profile"
              />
            </div>
            <div>
              <h2 className="font-poppins font-bold text-3xl mb-6 text-gray-900" data-testid="text-bio-title">
                Meet Your SEO Expert
              </h2>
              <div className="space-y-4 text-lg text-gray-600 leading-relaxed">
                <p data-testid="text-bio-para-1">
                  Hello! I'm Fatema Akter, a passionate Local SEO Expert dedicated to helping businesses achieve online success. With over 5 years of specialized experience in local search optimization, I've had the privilege of working with diverse businesses across three major markets: the United States, United Kingdom, and Italy.
                </p>
                <p data-testid="text-bio-para-2">
                  My journey in digital marketing began with a simple belief: every business deserves to be found by its ideal customers. This philosophy has driven me to master the intricate art and science of local SEO, helping over 200+ businesses transform their online presence and achieve remarkable growth.
                </p>
                <p data-testid="text-bio-para-3">
                  What sets me apart is my deep understanding of regional search behaviors and market dynamics. I don't just apply generic SEO tactics – I craft customized strategies that resonate with local audiences and drive meaningful results for each unique market.
                </p>
              </div>
              <div className="mt-8">
                <Link href="/contact">
                  <Button className="bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-600 transition-colors" data-testid="button-hire-me">
                    <i className="fas fa-handshake mr-2"></i>
                    Hire Me Today
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills & Certifications */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-skills-certifications">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-skills-title">
              Skills & <span className="text-seo-primary">Certifications</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-skills-description">
              Backed by industry-recognized certifications and proven expertise in cutting-edge SEO techniques
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Skills */}
            <Card className="p-8">
              <CardContent className="p-0">
                <h3 className="font-poppins font-bold text-2xl mb-8 text-center" data-testid="text-core-skills-title">Core SEO Skills</h3>
                <div className="space-y-6">
                  {[
                    { skill: "Local SEO Optimization", level: 98 },
                    { skill: "Keyword Research & Analysis", level: 95 },
                    { skill: "Technical SEO Auditing", level: 92 },
                    { skill: "Link Building Strategies", level: 90 },
                    { skill: "Google Analytics & Search Console", level: 96 },
                    { skill: "Multi-language SEO", level: 88 }
                  ].map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-gray-700" data-testid={`text-skill-${index}-name`}>{skill.skill}</span>
                        <span className="text-seo-primary font-bold" data-testid={`text-skill-${index}-level`}>{skill.level}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className="bg-seo-primary h-3 rounded-full transition-all duration-1000"
                          style={{ width: `${skill.level}%` }}
                          data-testid={`bar-skill-${index}`}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Certifications */}
            <Card className="p-8">
              <CardContent className="p-0">
                <h3 className="font-poppins font-bold text-2xl mb-8 text-center" data-testid="text-certifications-title">Professional Certifications</h3>
                <div className="space-y-6">
                  {[
                    {
                      title: "Google Analytics Certified",
                      issuer: "Google",
                      year: "2023",
                      icon: "fas fa-chart-line"
                    },
                    {
                      title: "Google Ads Certified",
                      issuer: "Google",
                      year: "2023", 
                      icon: "fas fa-bullhorn"
                    },
                    {
                      title: "SEMrush SEO Fundamentals",
                      issuer: "SEMrush Academy",
                      year: "2022",
                      icon: "fas fa-search"
                    },
                    {
                      title: "Local SEO Specialist",
                      issuer: "BrightLocal",
                      year: "2022",
                      icon: "fas fa-map-marker-alt"
                    },
                    {
                      title: "Technical SEO Certified",
                      issuer: "Screaming Frog",
                      year: "2023",
                      icon: "fas fa-cog"
                    }
                  ].map((cert, index) => (
                    <div key={index} className="flex items-center p-4 bg-white rounded-lg shadow-sm">
                      <div className="bg-seo-primary text-white w-12 h-12 rounded-full flex items-center justify-center mr-4">
                        <i className={`${cert.icon} text-lg`}></i>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900" data-testid={`text-cert-${index}-title`}>{cert.title}</h4>
                        <p className="text-sm text-gray-600" data-testid={`text-cert-${index}-issuer`}>{cert.issuer} • {cert.year}</p>
                      </div>
                      <div className="text-seo-secondary">
                        <i className="fas fa-certificate text-xl"></i>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Methodology & Approach */}
      <section className="py-20 bg-white" data-testid="section-methodology">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-methodology-title">
              My SEO <span className="text-seo-primary">Methodology</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-methodology-description">
              A proven 6-step approach that consistently delivers exceptional results for local businesses
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                title: "Discovery & Analysis",
                description: "Comprehensive audit of your current online presence, competitor analysis, and market research to identify opportunities.",
                icon: "fas fa-search"
              },
              {
                step: "02", 
                title: "Strategy Development",
                description: "Custom SEO strategy tailored to your business goals, target audience, and regional market dynamics.",
                icon: "fas fa-lightbulb"
              },
              {
                step: "03",
                title: "Technical Optimization", 
                description: "Fix technical issues, improve site speed, mobile responsiveness, and implement structured data markup.",
                icon: "fas fa-tools"
              },
              {
                step: "04",
                title: "Content & Keywords",
                description: "Optimize existing content and create new SEO-focused content targeting relevant local keywords.",
                icon: "fas fa-edit"
              },
              {
                step: "05",
                title: "Local Citations & Links",
                description: "Build high-quality local citations, manage online reviews, and establish authoritative backlinks.",
                icon: "fas fa-link"
              },
              {
                step: "06",
                title: "Monitor & Refine",
                description: "Continuous monitoring, detailed reporting, and strategy refinement to maximize long-term results.",
                icon: "fas fa-chart-bar"
              }
            ].map((step, index) => (
              <Card key={index} className="hover-lift relative overflow-hidden">
                <CardContent className="p-8 text-center">
                  <div className="absolute top-4 right-4 text-6xl font-bold text-seo-primary opacity-10" data-testid={`text-step-${index}-number`}>
                    {step.step}
                  </div>
                  <div className="bg-seo-primary text-white w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto relative z-10">
                    <i className={`${step.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4 relative z-10" data-testid={`text-step-${index}-title`}>{step.title}</h3>
                  <p className="text-gray-600 relative z-10" data-testid={`text-step-${index}-description`}>
                    {step.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Me */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-why-choose-me">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-why-choose-me-title">
              Why Choose Me as Your <span className="text-seo-primary">SEO Partner</span>
            </h2>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                alt="SEO Success Strategy"
                className="rounded-xl shadow-lg w-full"
                data-testid="img-why-choose-strategy"
              />
            </div>
            <div className="space-y-6">
              {[
                {
                  icon: "fas fa-trophy",
                  title: "Proven Track Record",
                  description: "200+ successful projects with an average 285% increase in organic traffic and 98% client satisfaction rate."
                },
                {
                  icon: "fas fa-globe-americas",
                  title: "Multi-Market Expertise", 
                  description: "Deep understanding of US, UK, and Italian markets with localized strategies for each region."
                },
                {
                  icon: "fas fa-clock",
                  title: "Fast Response Time",
                  description: "24-hour response guarantee with dedicated support throughout your SEO journey."
                },
                {
                  icon: "fas fa-handshake",
                  title: "Transparent Partnership",
                  description: "No long-term contracts, detailed monthly reports, and clear communication every step of the way."
                },
                {
                  icon: "fas fa-graduation-cap",
                  title: "Continuous Learning",
                  description: "Stay ahead with latest SEO trends, algorithm updates, and industry best practices."
                },
                {
                  icon: "fas fa-heart",
                  title: "Passionate Dedication",
                  description: "Your success is my success. I treat every project with personal attention and genuine care."
                }
              ].map((reason, index) => (
                <div key={index} className="flex items-start">
                  <div className="bg-seo-primary text-white w-12 h-12 rounded-full flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                    <i className={`${reason.icon} text-lg`}></i>
                  </div>
                  <div>
                    <h3 className="font-poppins font-semibold text-xl mb-2 text-gray-900" data-testid={`text-why-reason-${index}-title`}>
                      {reason.title}
                    </h3>
                    <p className="text-gray-600" data-testid={`text-why-reason-${index}-description`}>
                      {reason.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white text-center" data-testid="section-about-cta">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-4xl mb-6" data-testid="text-about-cta-title">
            Ready to Start Your SEO Journey?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto" data-testid="text-about-cta-description">
            Let's discuss how I can help your business dominate local search results and achieve sustainable growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-about-consultation">
                <i className="fas fa-calendar-alt mr-2"></i>
                Get Free Consultation
              </Button>
            </Link>
            <Link href="/services">
              <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-seo-primary transition-colors" data-testid="button-about-services">
                <i className="fas fa-list mr-2"></i>
                View Services
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
