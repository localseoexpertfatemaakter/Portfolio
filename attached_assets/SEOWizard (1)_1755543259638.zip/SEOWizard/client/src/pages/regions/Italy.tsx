import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Italy() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-red-600 text-white" data-testid="section-italy-hero">
        <div className="container mx-auto px-4 text-center">
          <div className="text-8xl mb-6" data-testid="text-italy-flag">🇮🇹</div>
          <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6" data-testid="text-italy-hero-title">
            Top Local SEO Expert in <span className="text-yellow-300">Italy</span>
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8" data-testid="text-italy-hero-subtitle">
            Dominate Italian local search results with proven SEO strategies tailored for businesses across Italy, from Milano to Roma, Napoli to Firenze
          </p>
          <Link href="/contact">
            <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-italy-contact">
              <i className="fas fa-phone mr-2"></i>
              Ottieni Consulenza SEO Italia
            </Button>
          </Link>
        </div>
      </section>

      {/* Italy Market Expertise */}
      <section className="py-20 bg-white" data-testid="section-italy-expertise">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-italy-expertise-title">
              Italian Market <span className="text-seo-primary">Expertise</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-italy-expertise-description">
              Deep understanding of Italian consumer behavior, local search patterns, and regional business dynamics
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Italy Local SEO Strategy" 
                className="rounded-xl shadow-lg w-full"
                data-testid="img-italy-strategy"
              />
            </div>
            <div>
              <h3 className="font-poppins font-bold text-3xl mb-6 text-gray-900" data-testid="text-italy-specialization-title">
                Italian SEO Specialization
              </h3>
              <div className="space-y-4">
                {[
                  {
                    title: "Major Italian Cities Coverage",
                    description: "Expert SEO services for Milano, Roma, Napoli, Torino, Firenze, Bologna, and 25+ other major Italian cities."
                  },
                  {
                    title: "Italian Consumer Psychology",
                    description: "In-depth understanding of Italian shopping patterns, review behaviors, and local search preferences specific to Italian culture."
                  },
                  {
                    title: "Italian Language & Culture SEO",
                    description: "Native-level optimization for Italian language nuances, regional dialects, and cultural preferences."
                  },
                  {
                    title: "Regional Italian SEO Strategies",
                    description: "Tailored approaches for different Italian regions, from North to South, understanding local business ecosystems."
                  }
                ].map((point, index) => (
                  <div key={index} className="flex items-start">
                    <div className="bg-green-600 text-white w-6 h-6 rounded-full flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                      <i className="fas fa-pizza-slice text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg text-gray-900 mb-1" data-testid={`text-italy-point-${index}-title`}>
                        {point.title}
                      </h4>
                      <p className="text-gray-600" data-testid={`text-italy-point-${index}-description`}>
                        {point.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Italy-Specific Services */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-italy-services">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-italy-services-title">
              Services for <span className="text-seo-primary">Italian Businesses</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-italy-services-description">
              Comprehensive SEO solutions designed specifically for the unique Italian market
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: "fas fa-map-marker-alt",
                title: "Italian Local Citations",
                description: "Build consistent NAP across top Italian directories like PagineGialle, TuttoCittà, and regional business listings.",
                features: ["Top 50 Italian directories", "Regional listings", "Local chamber listings"]
              },
              {
                icon: "fas fa-language",
                title: "Multi-Language SEO",
                description: "Optimization for Italian language with regional variations and dialect considerations for maximum local appeal.",
                features: ["Italian language optimization", "Regional dialects", "Cultural adaptation"]
              },
              {
                icon: "fas fa-search",
                title: "Italian Keyword Research",
                description: "Target high-converting keywords specific to Italian search behaviors and regional terminology.",
                features: ["Italian keywords", "Regional search terms", "Local intent analysis"]
              },
              {
                icon: "fas fa-store",
                title: "Google My Business Italia",
                description: "Complete optimization for Google My Business with Italian market considerations and local preferences.",
                features: ["Italian GMB optimization", "Local content creation", "Regional targeting"]
              },
              {
                icon: "fas fa-chart-line",
                title: "Italian Analytics & Reporting",
                description: "Detailed analytics tailored for Italian market performance, including local search rankings and traffic analysis.",
                features: ["Italian market insights", "Local ranking reports", "Regional traffic analysis"]
              },
              {
                icon: "fas fa-handshake",
                title: "Local Italian Link Building",
                description: "Strategic link building from authoritative Italian websites, local chambers, and industry associations.",
                features: ["Italian chamber links", "Local news sites", "Industry associations"]
              }
            ].map((service, index) => (
              <Card key={index} className="hover-lift">
                <CardContent className="p-8 text-center">
                  <div className="bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                    <i className={`${service.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4" data-testid={`text-italy-service-${index}-title`}>
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-6" data-testid={`text-italy-service-${index}-description`}>
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="text-sm text-gray-600 flex items-center" data-testid={`text-italy-service-${index}-feature-${featureIndex}`}>
                        <i className="fas fa-check text-seo-secondary mr-2"></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Italy Portfolio */}
      <section className="py-20 bg-white" data-testid="section-italy-portfolio">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-italy-portfolio-title">
              Italian Success <span className="text-seo-primary">Stories</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-italy-portfolio-description">
              Real results from Italian businesses that trusted me with their local SEO success
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {[
              {
                title: "Milan Fashion Boutique",
                location: "Milano, Lombardia",
                industry: "Fashion & Retail",
                result: "+250% Online Sales",
                description: "Boosted a Milan fashion boutique's online visibility, achieving first page rankings for local fashion keywords and increasing online sales by 250% within 5 months.",
                metrics: [
                  "250% increase in online sales",
                  "300% more store visits",
                  "#1 ranking for 'boutique Milano'",
                  "Expanded to 2 additional locations"
                ],
                image: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "Rome Restaurant Group",
                location: "Roma, Lazio",
                industry: "Food & Beverage",
                result: "+380% Prenotazioni",
                description: "Achieved remarkable growth for a Rome restaurant group by optimizing for local Italian food searches, resulting in 380% increase in reservations.",
                metrics: [
                  "380% increase in reservations",
                  "350% more online bookings",
                  "#1 ranking for 'miglior ristorante Roma'",
                  "Expanded to 5 additional locations"
                ],
                image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "Florence Tourism Business",
                location: "Firenze, Toscana",
                industry: "Tourism & Hospitality",
                result: "+290% Tourist Bookings",
                description: "Helped a Florence tourism business dominate local search results for tourist attractions, generating 290% more bookings from international visitors.",
                metrics: [
                  "290% increase in tourist bookings",
                  "Top 3 rankings for tourism keywords",
                  "250% increase in tour reservations",
                  "Expanded to Venice and Rome tours"
                ],
                image: "https://images.unsplash.com/photo-1543832923-44667a44c804?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "Naples Professional Services",
                location: "Napoli, Campania",
                industry: "Professional Services",
                result: "+270% Client Consultations",
                description: "Transformed a Naples professional services firm's online presence, achieving 270% more client consultations and establishing market leadership in Southern Italy.",
                metrics: [
                  "270% increase in consultations",
                  "Top 5 rankings for service keywords",
                  "200% increase in phone inquiries",
                  "Expanded service area to Campania region"
                ],
                image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              }
            ].map((project, index) => (
              <Card key={index} className="hover-lift overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-48 object-cover"
                  data-testid={`img-italy-project-${index}`}
                />
                <CardContent className="p-8">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-poppins font-semibold text-xl mb-2" data-testid={`text-italy-project-${index}-title`}>
                        {project.title}
                      </h3>
                      <p className="text-sm text-gray-600 mb-1" data-testid={`text-italy-project-${index}-location`}>
                        <i className="fas fa-map-marker-alt mr-1"></i>
                        {project.location}
                      </p>
                      <p className="text-sm text-gray-600" data-testid={`text-italy-project-${index}-industry`}>
                        <i className="fas fa-industry mr-1"></i>
                        {project.industry}
                      </p>
                    </div>
                    <div className="bg-seo-secondary text-white px-3 py-1 rounded-full text-sm font-semibold" data-testid={`text-italy-project-${index}-result`}>
                      {project.result}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-6" data-testid={`text-italy-project-${index}-description`}>
                    {project.description}
                  </p>
                  <div>
                    <h4 className="font-semibold mb-3">Risultati Chiave:</h4>
                    <ul className="space-y-2">
                      {project.metrics.map((metric, metricIndex) => (
                        <li key={metricIndex} className="flex items-center text-sm text-gray-600" data-testid={`text-italy-project-${index}-metric-${metricIndex}`}>
                          <i className="fas fa-check text-seo-secondary mr-2"></i>
                          {metric}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Italy Testimonials */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-italy-testimonials">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-italy-testimonials-title">
              What Italian Clients <span className="text-seo-primary">Say</span>
            </h2>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                name: "Giuseppe Rossi",
                title: "Boutique Owner",
                location: "Milano, Italy",
                rating: 5,
                testimonial: "Fantastico! Fatema understood the Italian market perfectly. Our online sales increased by 250% and we're now the top-ranked fashion boutique in Milan for local searches. Servizio eccellente!"
              },
              {
                name: "Maria Bianchi",
                title: "Restaurant Owner",
                location: "Roma, Italy",
                rating: 5,
                testimonial: "Incredibile! Our restaurant group now dominates local search in Rome. Reservations increased by 380%, and we've opened 5 new locations. Fatema capisce davvero il mercato italiano!"
              },
              {
                name: "Antonio Ferrari",
                title: "Tourism Director",
                location: "Firenze, Italy",
                rating: 5,
                testimonial: "Eccezionale! Our tourism business now ranks #1 for Florence attractions. Tourist bookings increased by 290% and we've expanded to Venice and Rome. Highly recommended for Italian businesses!"
              }
            ].map((testimonial, index) => (
              <Card key={index} className="p-8">
                <CardContent className="p-0">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                      {testimonial.name[0]}
                    </div>
                    <div className="ml-4">
                      <div className="font-semibold" data-testid={`text-italy-testimonial-${index}-name`}>{testimonial.name}</div>
                      <div className="text-sm text-gray-600" data-testid={`text-italy-testimonial-${index}-title`}>
                        {testimonial.title}, {testimonial.location}
                      </div>
                    </div>
                  </div>
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <i key={i} className="fas fa-star"></i>
                    ))}
                  </div>
                  <p className="text-gray-600 italic" data-testid={`text-italy-testimonial-${index}-content`}>
                    "{testimonial.testimonial}"
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Italy Keywords Focus */}
      <section className="py-20 bg-white" data-testid="section-italy-keywords">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-italy-keywords-title">
              Italian SEO <span className="text-seo-primary">Keywords</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-italy-keywords-description">
              Targeting high-converting keywords that Italian customers actually search for
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              "experto seo local madrid",
              "local seo expert barcelona",
              "experte seo local",
              "local seo expert",
              "experto seo local",
              "local seo citation expert",
              "hire local seo expert",
              "top local seo expert",
              "local seo expert near me",
              "experto en seo local barcelona"
            ].map((keyword, index) => (
              <div key={index} className="bg-seo-gray-50 p-4 rounded-lg text-center hover:bg-seo-primary hover:text-white transition-colors cursor-pointer" data-testid={`text-italy-keyword-${index}`}>
                <i className="fas fa-search mr-2"></i>
                {keyword}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-red-600 text-white text-center" data-testid="section-italy-cta">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-4xl mb-6" data-testid="text-italy-cta-title">
            Pronto a Dominare le Ricerche Locali in Italia?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto" data-testid="text-italy-cta-description">
            Join 60+ successful Italian businesses that trust me for their local SEO success
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-italy-cta-contact">
                <i className="fas fa-rocket mr-2"></i>
                Ottieni Strategia SEO Italia
              </Button>
            </Link>
            <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-green-600 transition-colors" data-testid="button-italy-cta-call">
              <i className="fas fa-phone mr-2"></i>
              Call: 01516089599
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
