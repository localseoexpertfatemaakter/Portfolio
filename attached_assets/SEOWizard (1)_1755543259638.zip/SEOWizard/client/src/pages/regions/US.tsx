import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function US() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-red-600 to-blue-600 text-white" data-testid="section-us-hero">
        <div className="container mx-auto px-4 text-center">
          <div className="text-8xl mb-6" data-testid="text-us-flag">🇺🇸</div>
          <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6" data-testid="text-us-hero-title">
            Top Local SEO Expert in <span className="text-yellow-300">United States</span>
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8" data-testid="text-us-hero-subtitle">
            Dominate American local search results with proven SEO strategies tailored for US businesses across all 50 states
          </p>
          <Link href="/contact">
            <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-us-contact">
              <i className="fas fa-phone mr-2"></i>
              Get US SEO Consultation
            </Button>
          </Link>
        </div>
      </section>

      {/* US Market Expertise */}
      <section className="py-20 bg-white" data-testid="section-us-expertise">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-us-expertise-title">
              US Market <span className="text-seo-primary">Expertise</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-us-expertise-description">
              Deep understanding of American consumer behavior, local search patterns, and regional business dynamics
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1444927714506-8492d94b5ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="US Local SEO Strategy" 
                className="rounded-xl shadow-lg w-full"
                data-testid="img-us-strategy"
              />
            </div>
            <div>
              <h3 className="font-poppins font-bold text-3xl mb-6 text-gray-900" data-testid="text-us-specialization-title">
                US SEO Specialization
              </h3>
              <div className="space-y-4">
                {[
                  {
                    title: "Major US Cities Coverage",
                    description: "Expert SEO services for Houston, New York City, Los Angeles, Chicago, Tampa, San Diego, and 45+ other major US cities."
                  },
                  {
                    title: "American Consumer Psychology",
                    description: "In-depth understanding of US shopping patterns, review behaviors, and local search preferences."
                  },
                  {
                    title: "Yelp & Google My Business Mastery",
                    description: "Specialized optimization for platforms that dominate US local search results."
                  },
                  {
                    title: "State-Specific SEO Strategies",
                    description: "Tailored approaches for different state regulations, local directories, and regional preferences."
                  }
                ].map((point, index) => (
                  <div key={index} className="flex items-start">
                    <div className="bg-red-500 text-white w-6 h-6 rounded-full flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                      <i className="fas fa-star text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg text-gray-900 mb-1" data-testid={`text-us-point-${index}-title`}>
                        {point.title}
                      </h4>
                      <p className="text-gray-600" data-testid={`text-us-point-${index}-description`}>
                        {point.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* US-Specific Services */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-us-services">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-us-services-title">
              Services for <span className="text-seo-primary">US Businesses</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-us-services-description">
              Comprehensive SEO solutions designed specifically for the competitive American market
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: "fas fa-map-marker-alt",
                title: "US Local Citations",
                description: "Build consistent NAP (Name, Address, Phone) across top American directories like Yelp, Yellow Pages, and industry-specific platforms.",
                features: ["Top 50 US directories", "Industry-specific listings", "NAP consistency monitoring"]
              },
              {
                icon: "fas fa-star",
                title: "Yelp Optimization",
                description: "Complete Yelp profile optimization and review management strategy for maximum local visibility in the US market.",
                features: ["Profile optimization", "Review response strategy", "Yelp advertising guidance"]
              },
              {
                icon: "fas fa-search",
                title: "US Keyword Research",
                description: "Target high-converting keywords specific to American search behaviors and regional terminology.",
                features: ["Local US keywords", "Commercial intent analysis", "Regional search trends"]
              },
              {
                icon: "fas fa-mobile-alt",
                title: "Mobile-First Optimization",
                description: "Optimize for mobile-first indexing with focus on US mobile search patterns and user preferences.",
                features: ["Mobile page speed", "Touch-friendly design", "Local mobile searches"]
              },
              {
                icon: "fas fa-chart-line",
                title: "US Analytics & Reporting",
                description: "Detailed analytics tailored for US market performance, including local search rankings and traffic analysis.",
                features: ["Google My Business insights", "Local ranking reports", "US traffic analysis"]
              },
              {
                icon: "fas fa-handshake",
                title: "Local US Link Building",
                description: "Strategic link building from authoritative US websites, local chambers of commerce, and industry associations.",
                features: ["Chamber of commerce links", "Local news sites", "US business directories"]
              }
            ].map((service, index) => (
              <Card key={index} className="hover-lift">
                <CardContent className="p-8 text-center">
                  <div className="bg-red-500 text-white w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                    <i className={`${service.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4" data-testid={`text-us-service-${index}-title`}>
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-6" data-testid={`text-us-service-${index}-description`}>
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="text-sm text-gray-600 flex items-center" data-testid={`text-us-service-${index}-feature-${featureIndex}`}>
                        <i className="fas fa-check text-seo-secondary mr-2"></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* US Portfolio */}
      <section className="py-20 bg-white" data-testid="section-us-portfolio">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-us-portfolio-title">
              US Success <span className="text-seo-primary">Stories</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-us-portfolio-description">
              Real results from American businesses that trusted me with their local SEO success
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {[
              {
                title: "Houston Restaurant Chain",
                location: "Houston, Texas",
                industry: "Food & Beverage",
                result: "+285% Local Traffic",
                description: "Transformed a 12-location restaurant chain's online presence, achieving #1 rankings for 'best restaurant Houston' and related local keywords. Increased reservations by 150% within 6 months.",
                metrics: [
                  "285% increase in organic traffic",
                  "150% more online reservations", 
                  "#1 ranking for 'best restaurant Houston'",
                  "12 locations optimized"
                ],
                image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "Tampa Local SEO Expert",
                location: "Tampa, Florida", 
                industry: "Professional Services",
                result: "+320% Qualified Leads",
                description: "Helped a Tampa-based service business dominate local search results for professional services, generating 320% more qualified leads and establishing market leadership.",
                metrics: [
                  "320% increase in qualified leads",
                  "Top 3 rankings for target keywords",
                  "150% increase in phone calls",
                  "90% reduction in cost per lead"
                ],
                image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "San Diego Local SEO Success",
                location: "San Diego, California",
                industry: "Healthcare", 
                result: "+250% Patient Inquiries",
                description: "Boosted a healthcare practice's local visibility in competitive San Diego market, resulting in 250% more patient inquiries and expanded service area reach.",
                metrics: [
                  "250% increase in patient inquiries",
                  "Top 5 rankings for medical keywords",
                  "200% growth in appointment bookings",
                  "Expanded service area coverage"
                ],
                image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "NYC Local Business Growth",
                location: "New York City, New York",
                industry: "Retail",
                result: "+400% Online Sales",
                description: "Achieved remarkable growth for a NYC retail business by optimizing for local e-commerce searches, resulting in 400% increase in online sales and store visits.",
                metrics: [
                  "400% increase in online sales",
                  "300% more store visits",
                  "#1 ranking for local retail keywords", 
                  "Expanded to 3 additional locations"
                ],
                image: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              }
            ].map((project, index) => (
              <Card key={index} className="hover-lift overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-48 object-cover"
                  data-testid={`img-us-project-${index}`}
                />
                <CardContent className="p-8">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-poppins font-semibold text-xl mb-2" data-testid={`text-us-project-${index}-title`}>
                        {project.title}
                      </h3>
                      <p className="text-sm text-gray-600 mb-1" data-testid={`text-us-project-${index}-location`}>
                        <i className="fas fa-map-marker-alt mr-1"></i>
                        {project.location}
                      </p>
                      <p className="text-sm text-gray-600" data-testid={`text-us-project-${index}-industry`}>
                        <i className="fas fa-industry mr-1"></i>
                        {project.industry}
                      </p>
                    </div>
                    <div className="bg-seo-secondary text-white px-3 py-1 rounded-full text-sm font-semibold" data-testid={`text-us-project-${index}-result`}>
                      {project.result}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-6" data-testid={`text-us-project-${index}-description`}>
                    {project.description}
                  </p>
                  <div>
                    <h4 className="font-semibold mb-3">Key Results:</h4>
                    <ul className="space-y-2">
                      {project.metrics.map((metric, metricIndex) => (
                        <li key={metricIndex} className="flex items-center text-sm text-gray-600" data-testid={`text-us-project-${index}-metric-${metricIndex}`}>
                          <i className="fas fa-check text-seo-secondary mr-2"></i>
                          {metric}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* US Testimonials */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-us-testimonials">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-us-testimonials-title">
              What US Clients <span className="text-seo-primary">Say</span>
            </h2>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                name: "Michael Johnson",
                title: "Restaurant Owner",
                location: "Houston, Texas",
                rating: 5,
                testimonial: "Fatema transformed our online presence completely. We went from page 3 to #1 for 'best restaurant Houston' in just 4 months. Our reservations increased by 150% and we're now the go-to restaurant in our area!"
              },
              {
                name: "Jennifer Rodriguez", 
                title: "Healthcare Administrator",
                location: "Tampa, Florida",
                rating: 5,
                testimonial: "Outstanding results! Our medical practice now dominates local search in Tampa. Patient inquiries have tripled, and we're consistently ranked in the top 3 for all our target keywords. Worth every penny!"
              },
              {
                name: "David Chen",
                title: "Retail Business Owner",
                location: "San Diego, California", 
                rating: 5,
                testimonial: "Amazing expertise in US local SEO! Fatema helped us grow from a single store to 3 locations in just 8 months. Our online sales increased by 400% and foot traffic doubled. Highly recommended!"
              }
            ].map((testimonial, index) => (
              <Card key={index} className="p-8">
                <CardContent className="p-0">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                      {testimonial.name[0]}
                    </div>
                    <div className="ml-4">
                      <div className="font-semibold" data-testid={`text-us-testimonial-${index}-name`}>{testimonial.name}</div>
                      <div className="text-sm text-gray-600" data-testid={`text-us-testimonial-${index}-title`}>
                        {testimonial.title}, {testimonial.location}
                      </div>
                    </div>
                  </div>
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <i key={i} className="fas fa-star"></i>
                    ))}
                  </div>
                  <p className="text-gray-600 italic" data-testid={`text-us-testimonial-${index}-content`}>
                    "{testimonial.testimonial}"
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* US Keywords Focus */}
      <section className="py-20 bg-white" data-testid="section-us-keywords">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-us-keywords-title">
              US SEO <span className="text-seo-primary">Keywords</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-us-keywords-description">
              Targeting high-converting keywords that US customers actually search for
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              "top local seo expert",
              "tampa local seo experts", 
              "local seo expert houston",
              "local seo expert nyc",
              "san diego local seo experts",
              "expert local seo tools",
              "local seo experts katy",
              "local seo expert the woodlands",
              "winnipeg local seo expert",
              "local seo experts in michigan"
            ].map((keyword, index) => (
              <div key={index} className="bg-seo-gray-50 p-4 rounded-lg text-center hover:bg-seo-primary hover:text-white transition-colors cursor-pointer" data-testid={`text-us-keyword-${index}`}>
                <i className="fas fa-search mr-2"></i>
                {keyword}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-red-600 to-blue-600 text-white text-center" data-testid="section-us-cta">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-4xl mb-6" data-testid="text-us-cta-title">
            Ready to Dominate US Local Search?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto" data-testid="text-us-cta-description">
            Join 100+ successful US businesses that trust me for their local SEO success
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-us-cta-contact">
                <i className="fas fa-rocket mr-2"></i>
                Get US SEO Strategy
              </Button>
            </Link>
            <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-red-600 transition-colors" data-testid="button-us-cta-call">
              <i className="fas fa-phone mr-2"></i>
              Call: 01516089599
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
