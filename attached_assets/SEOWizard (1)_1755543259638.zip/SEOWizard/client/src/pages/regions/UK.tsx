import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function UK() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-red-600 text-white" data-testid="section-uk-hero">
        <div className="container mx-auto px-4 text-center">
          <div className="text-8xl mb-6" data-testid="text-uk-flag">🇬🇧</div>
          <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6" data-testid="text-uk-hero-title">
            Top Local SEO Expert in <span className="text-yellow-300">United Kingdom</span>
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8" data-testid="text-uk-hero-subtitle">
            Dominate British local search results with proven SEO strategies tailored for UK businesses across England, Scotland, Wales, and Northern Ireland
          </p>
          <Link href="/contact">
            <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-uk-contact">
              <i className="fas fa-phone mr-2"></i>
              Get UK SEO Consultation
            </Button>
          </Link>
        </div>
      </section>

      {/* UK Market Expertise */}
      <section className="py-20 bg-white" data-testid="section-uk-expertise">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-uk-expertise-title">
              UK Market <span className="text-seo-primary">Expertise</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-uk-expertise-description">
              Deep understanding of British consumer behavior, local search patterns, and regional business dynamics
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="UK Local SEO Strategy" 
                className="rounded-xl shadow-lg w-full"
                data-testid="img-uk-strategy"
              />
            </div>
            <div>
              <h3 className="font-poppins font-bold text-3xl mb-6 text-gray-900" data-testid="text-uk-specialization-title">
                UK SEO Specialization
              </h3>
              <div className="space-y-4">
                {[
                  {
                    title: "Major UK Cities Coverage",
                    description: "Expert SEO services for London, Birmingham, Manchester, Glasgow, Liverpool, Leeds, and 30+ other major British cities."
                  },
                  {
                    title: "British Consumer Psychology",
                    description: "In-depth understanding of UK shopping patterns, review behaviors, and local search preferences specific to British culture."
                  },
                  {
                    title: "Trustpilot & Google My Business",
                    description: "Specialized optimization for platforms that dominate UK local search results and consumer trust."
                  },
                  {
                    title: "Regional UK SEO Strategies",
                    description: "Tailored approaches for different UK regions, local councils, and British-specific directories and regulations."
                  }
                ].map((point, index) => (
                  <div key={index} className="flex items-start">
                    <div className="bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                      <i className="fas fa-crown text-xs"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg text-gray-900 mb-1" data-testid={`text-uk-point-${index}-title`}>
                        {point.title}
                      </h4>
                      <p className="text-gray-600" data-testid={`text-uk-point-${index}-description`}>
                        {point.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* UK-Specific Services */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-uk-services">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-uk-services-title">
              Services for <span className="text-seo-primary">UK Businesses</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-uk-services-description">
              Comprehensive SEO solutions designed specifically for the competitive British market
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: "fas fa-map-marker-alt",
                title: "UK Local Citations",
                description: "Build consistent NAP across top British directories like Yell, Thomson Local, and industry-specific UK platforms.",
                features: ["Top 50 UK directories", "Local council listings", "British industry directories"]
              },
              {
                icon: "fas fa-heart",
                title: "Trustpilot Optimization",
                description: "Complete Trustpilot profile optimization and review management strategy for maximum credibility in the UK market.",
                features: ["Profile optimization", "Review strategy", "Trust building campaigns"]
              },
              {
                icon: "fas fa-search",
                title: "UK Keyword Research",
                description: "Target high-converting keywords specific to British English and UK regional search behaviors.",
                features: ["British English keywords", "Regional UK terms", "Local search trends"]
              },
              {
                icon: "fas fa-shield-alt",
                title: "GDPR Compliance SEO",
                description: "Ensure your SEO strategy complies with UK GDPR regulations and data protection requirements.",
                features: ["GDPR-compliant tracking", "Privacy-focused SEO", "Legal compliance"]
              },
              {
                icon: "fas fa-chart-line",
                title: "UK Analytics & Reporting",
                description: "Detailed analytics tailored for UK market performance, including local search rankings and British traffic analysis.",
                features: ["UK-specific insights", "Local ranking reports", "British traffic analysis"]
              },
              {
                icon: "fas fa-building",
                title: "Local UK Link Building",
                description: "Strategic link building from authoritative UK websites, local chambers, and British industry associations.",
                features: ["UK chamber links", "Local news sites", "British business networks"]
              }
            ].map((service, index) => (
              <Card key={index} className="hover-lift">
                <CardContent className="p-8 text-center">
                  <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                    <i className={`${service.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4" data-testid={`text-uk-service-${index}-title`}>
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-6" data-testid={`text-uk-service-${index}-description`}>
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="text-sm text-gray-600 flex items-center" data-testid={`text-uk-service-${index}-feature-${featureIndex}`}>
                        <i className="fas fa-check text-seo-secondary mr-2"></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* UK Portfolio */}
      <section className="py-20 bg-white" data-testid="section-uk-portfolio">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-uk-portfolio-title">
              UK Success <span className="text-seo-primary">Stories</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-uk-portfolio-description">
              Real results from British businesses that trusted me with their local SEO success
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {[
              {
                title: "London Law Firm",
                location: "London, England",
                industry: "Legal Services",
                result: "+320% Qualified Leads",
                description: "Transformed a prestigious London law firm's online presence, achieving top 3 rankings for competitive legal keywords and generating 320% more qualified leads within 8 months.",
                metrics: [
                  "320% increase in qualified leads",
                  "Top 3 rankings for legal keywords",
                  "150% increase in consultation requests",
                  "85% reduction in cost per lead"
                ],
                image: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "Birmingham Healthcare Practice",
                location: "Birmingham, England",
                industry: "Healthcare",
                result: "+280% Patient Bookings",
                description: "Boosted a Birmingham healthcare practice's local visibility, resulting in 280% more patient bookings and expanded service area coverage across the West Midlands.",
                metrics: [
                  "280% increase in patient bookings",
                  "Top 5 rankings for medical keywords",
                  "200% growth in online appointments",
                  "Expanded to West Midlands coverage"
                ],
                image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "Manchester Restaurant Group",
                location: "Manchester, England",
                industry: "Food & Beverage",
                result: "+350% Reservations",
                description: "Achieved remarkable growth for a Manchester restaurant group by optimizing for local food searches, resulting in 350% increase in reservations and table bookings.",
                metrics: [
                  "350% increase in reservations",
                  "300% more online bookings",
                  "#1 ranking for 'best restaurant Manchester'",
                  "Expanded to 4 additional locations"
                ],
                image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              },
              {
                title: "Oxford Professional Services",
                location: "Oxford, England",
                industry: "Professional Services",
                result: "+290% Client Inquiries",
                description: "Helped an Oxford-based professional services firm dominate local search results, generating 290% more client inquiries and establishing market leadership in the region.",
                metrics: [
                  "290% increase in client inquiries",
                  "Top 3 rankings for service keywords",
                  "250% increase in phone consultations",
                  "Expanded service area to surrounding counties"
                ],
                image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
              }
            ].map((project, index) => (
              <Card key={index} className="hover-lift overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-48 object-cover"
                  data-testid={`img-uk-project-${index}`}
                />
                <CardContent className="p-8">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-poppins font-semibold text-xl mb-2" data-testid={`text-uk-project-${index}-title`}>
                        {project.title}
                      </h3>
                      <p className="text-sm text-gray-600 mb-1" data-testid={`text-uk-project-${index}-location`}>
                        <i className="fas fa-map-marker-alt mr-1"></i>
                        {project.location}
                      </p>
                      <p className="text-sm text-gray-600" data-testid={`text-uk-project-${index}-industry`}>
                        <i className="fas fa-industry mr-1"></i>
                        {project.industry}
                      </p>
                    </div>
                    <div className="bg-seo-secondary text-white px-3 py-1 rounded-full text-sm font-semibold" data-testid={`text-uk-project-${index}-result`}>
                      {project.result}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-6" data-testid={`text-uk-project-${index}-description`}>
                    {project.description}
                  </p>
                  <div>
                    <h4 className="font-semibold mb-3">Key Results:</h4>
                    <ul className="space-y-2">
                      {project.metrics.map((metric, metricIndex) => (
                        <li key={metricIndex} className="flex items-center text-sm text-gray-600" data-testid={`text-uk-project-${index}-metric-${metricIndex}`}>
                          <i className="fas fa-check text-seo-secondary mr-2"></i>
                          {metric}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* UK Testimonials */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-uk-testimonials">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-uk-testimonials-title">
              What UK Clients <span className="text-seo-primary">Say</span>
            </h2>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah Thompson",
                title: "Law Firm Partner",
                location: "London, England",
                rating: 5,
                testimonial: "Outstanding results! Our firm now ranks #1 for competitive legal keywords in London. The quality of leads has improved dramatically, and our client base has grown by 300%. Fatema truly understands the UK market."
              },
              {
                name: "James Richardson",
                title: "Healthcare Director",
                location: "Birmingham, England",
                rating: 5,
                testimonial: "Brilliant work! Our healthcare practice now dominates local search in Birmingham. Patient bookings have increased by 280%, and we're consistently ranked in the top 3 for all our medical keywords. Highly professional service."
              },
              {
                name: "Emma Wilson",
                title: "Restaurant Owner",
                location: "Manchester, England",
                rating: 5,
                testimonial: "Absolutely fantastic! Fatema helped us become the #1 restaurant in Manchester for local searches. Our reservations increased by 350% and we've opened 4 new locations. Best investment we've ever made!"
              }
            ].map((testimonial, index) => (
              <Card key={index} className="p-8">
                <CardContent className="p-0">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                      {testimonial.name[0]}
                    </div>
                    <div className="ml-4">
                      <div className="font-semibold" data-testid={`text-uk-testimonial-${index}-name`}>{testimonial.name}</div>
                      <div className="text-sm text-gray-600" data-testid={`text-uk-testimonial-${index}-title`}>
                        {testimonial.title}, {testimonial.location}
                      </div>
                    </div>
                  </div>
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <i key={i} className="fas fa-star"></i>
                    ))}
                  </div>
                  <p className="text-gray-600 italic" data-testid={`text-uk-testimonial-${index}-content`}>
                    "{testimonial.testimonial}"
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* UK Keywords Focus */}
      <section className="py-20 bg-white" data-testid="section-uk-keywords">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-uk-keywords-title">
              UK SEO <span className="text-seo-primary">Keywords</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-uk-keywords-description">
              Targeting high-converting keywords that British customers actually search for
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              "local seo expert london",
              "uk local seo expert",
              "best local seo experts",
              "local seo expert near me",
              "seo expert for local businesses oxford",
              "local business seo expert",
              "expert local seo tools",
              "local seo citation expert",
              "google local seo expert",
              "local seo expert hertfordshire"
            ].map((keyword, index) => (
              <div key={index} className="bg-seo-gray-50 p-4 rounded-lg text-center hover:bg-seo-primary hover:text-white transition-colors cursor-pointer" data-testid={`text-uk-keyword-${index}`}>
                <i className="fas fa-search mr-2"></i>
                {keyword}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-red-600 text-white text-center" data-testid="section-uk-cta">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-4xl mb-6" data-testid="text-uk-cta-title">
            Ready to Dominate UK Local Search?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto" data-testid="text-uk-cta-description">
            Join 80+ successful UK businesses that trust me for their local SEO success
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-uk-cta-contact">
                <i className="fas fa-rocket mr-2"></i>
                Get UK SEO Strategy
              </Button>
            </Link>
            <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-blue-600 transition-colors" data-testid="button-uk-cta-call">
              <i className="fas fa-phone mr-2"></i>
              Call: 01516089599
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
