import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  website: z.string().url("Please enter a valid website URL").optional().or(z.literal("")),
  region: z.string().min(1, "Please select a region of interest"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      website: "",
      region: "",
      message: "",
    },
  });

  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);

    try {
      // Simulate form submission - in real implementation, this would call an API
      await new Promise(resolve => setTimeout(resolve, 1000));

      console.log("Contact form submission:", data);

      toast({
        title: "Message Sent Successfully!",
        description: "Thank you for your inquiry. I'll get back to you within 24 hours.",
        duration: 5000,
      });

      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again or contact me directly.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const openWhatsApp = () => {
    const phoneNumber = '01516089599';
    const message = `Hi Fatema! I'm interested in your SEO services. Can we discuss my requirements?`;
    const whatsappURL = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappURL, '_blank');
  };

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 gradient-bg text-white" data-testid="section-contact-hero">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6" data-testid="text-contact-hero-title">
            Get In <span className="text-yellow-300">Touch</span>
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8" data-testid="text-contact-hero-subtitle">
            Ready to boost your local search rankings? Contact me today for a free consultation and custom SEO strategy tailored to your business needs.
          </p>
        </div>
      </section>

      {/* Contact Form and Information */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-contact-main">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="shadow-lg" data-testid="card-contact-form">
              <CardContent className="p-8">
                <h2 className="font-poppins font-bold text-2xl mb-6 text-gray-900" data-testid="text-form-title">
                  Send a Message
                </h2>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="form-contact">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-700 font-medium">Name *</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Your full name" 
                              {...field}
                              className="focus:ring-2 focus:ring-seo-primary focus:border-transparent"
                              data-testid="input-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-700 font-medium">Email *</FormLabel>
                          <FormControl>
                            <Input 
                              type="email"
                              placeholder="your@email.com" 
                              {...field}
                              className="focus:ring-2 focus:ring-seo-primary focus:border-transparent"
                              data-testid="input-email"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-700 font-medium">Business Website</FormLabel>
                          <FormControl>
                            <Input 
                              type="url"
                              placeholder="https://yourwebsite.com" 
                              {...field}
                              className="focus:ring-2 focus:ring-seo-primary focus:border-transparent"
                              data-testid="input-website"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="region"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-700 font-medium">Region of Interest *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl className="focus:ring-2 focus:ring-seo-primary focus:border-transparent" data-testid="select-region">
                              <SelectTrigger>
                                <SelectValue placeholder="Select a region" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="us">🇺🇸 United States</SelectItem>
                              <SelectItem value="uk">🇬🇧 United Kingdom</SelectItem>
                              <SelectItem value="italy">🇮🇹 Italy</SelectItem>
                              <SelectItem value="all">All Regions</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-700 font-medium">Message *</FormLabel>
                          <FormControl>
                            <Textarea 
                              rows={5}
                              placeholder="Tell me about your SEO goals and current challenges..." 
                              {...field}
                              className="focus:ring-2 focus:ring-seo-primary focus:border-transparent resize-none"
                              data-testid="textarea-message"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full bg-seo-primary text-white py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors disabled:opacity-50"
                      disabled={isSubmitting}
                      data-testid="button-submit-form"
                    >
                      {isSubmitting ? (
                        <>
                          <i className="fas fa-spinner fa-spin mr-2"></i>
                          Sending...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-paper-plane mr-2"></i>
                          Schedule Consultation
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <div className="space-y-8">
              {/* Contact Details */}
              <Card className="shadow-lg" data-testid="card-contact-info">
                <CardContent className="p-8">
                  <h3 className="font-poppins font-bold text-2xl mb-6 text-gray-900" data-testid="text-contact-info-title">
                    Contact Information
                  </h3>
                  <div className="space-y-6">
                    <div className="flex items-center">
                      <div className="bg-seo-primary text-white w-12 h-12 rounded-full flex items-center justify-center mr-4">
                        <i className="fas fa-user"></i>
                      </div>
                      <div>
                        <div className="font-semibold text-lg" data-testid="text-contact-name">Fatema Akter</div>
                        <div className="text-gray-600" data-testid="text-contact-title">Local SEO Expert</div>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <div className="bg-seo-secondary text-white w-12 h-12 rounded-full flex items-center justify-center mr-4">
                        <i className="fas fa-phone"></i>
                      </div>
                      <div>
                        <div className="font-semibold">Phone</div>
                        <button 
                          onClick={openWhatsApp}
                          className="text-seo-primary hover:underline text-left"
                          data-testid="link-phone"
                        >
                          01516089599
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <div className="bg-seo-accent text-gray-900 w-12 h-12 rounded-full flex items-center justify-center mr-4">
                        <i className="fas fa-envelope"></i>
                      </div>
                      <div>
                        <div className="font-semibold">Email</div>
                        <a 
                          href="mailto:fatema@seoexpert.com" 
                          className="text-seo-primary hover:underline"
                          data-testid="link-email"
                        >
                          fatema@seoexpert.com
                        </a>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <div className="bg-green-500 text-white w-12 h-12 rounded-full flex items-center justify-center mr-4">
                        <i className="fab fa-whatsapp"></i>
                      </div>
                      <div>
                        <div className="font-semibold">WhatsApp</div>
                        <button 
                          onClick={openWhatsApp}
                          className="text-seo-primary hover:underline"
                          data-testid="button-whatsapp-contact"
                        >
                          Quick Response 24/7
                        </button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Why Contact Me */}
              <Card className="shadow-lg" data-testid="card-why-contact">
                <CardContent className="p-8">
                  <h3 className="font-poppins font-bold text-2xl mb-6 text-gray-900" data-testid="text-why-contact-title">
                    Why Contact Me?
                  </h3>
                  <div className="space-y-4">
                    {[
                      "Free SEO audit within 24 hours",
                      "Custom strategy for your region",
                      "No long-term contracts required",
                      "Proven results across 3 countries",
                      "98% client satisfaction rate",
                      "Transparent pricing and reporting"
                    ].map((benefit, index) => (
                      <div key={index} className="flex items-start">
                        <i className="fas fa-check-circle text-seo-secondary mt-1 mr-3"></i>
                        <span className="text-gray-600" data-testid={`text-benefit-${index}`}>
                          {benefit}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-20 bg-white" data-testid="section-contact-methods">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-contact-methods-title">
              Multiple Ways to <span className="text-seo-primary">Connect</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-contact-methods-description">
              Choose the communication method that works best for you
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: "fas fa-envelope",
                title: "Email",
                description: "Send detailed inquiries and receive comprehensive responses",
                action: "Send Email",
                color: "bg-seo-primary",
                onClick: () => window.location.href = "mailto:fatema@seoexpert.com"
              },
              {
                icon: "fas fa-phone",
                title: "WhatsApp Call",
                description: "Direct consultation for immediate answers and personalized advice",
                action: "WhatsApp Now",
                color: "bg-seo-secondary", 
                onClick: openWhatsApp
              },
              {
                icon: "fab fa-whatsapp",
                title: "WhatsApp",
                description: "Quick messaging for fast responses and easy communication",
                action: "Chat on WhatsApp",
                color: "bg-green-500",
                onClick: openWhatsApp
              },
              {
                icon: "fas fa-calendar-alt",
                title: "Schedule Meeting",
                description: "Book a dedicated time slot for in-depth strategy discussion",
                action: "Book Consultation",
                color: "bg-purple-600",
                onClick: () => form.handleSubmit(onSubmit)()
              }
            ].map((method, index) => (
              <Card key={index} className="text-center hover-lift">
                <CardContent className="p-8">
                  <div className={`${method.color} text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6`}>
                    <i className={`${method.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4" data-testid={`text-method-${index}-title`}>
                    {method.title}
                  </h3>
                  <p className="text-gray-600 mb-6 leading-relaxed" data-testid={`text-method-${index}-description`}>
                    {method.description}
                  </p>
                  <Button 
                    className="bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors"
                    onClick={method.onClick}
                    data-testid={`button-method-${index}`}
                  >
                    <i className="fas fa-arrow-right mr-2"></i>
                    {method.action}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-contact-faq">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-faq-title">
              Frequently Asked <span className="text-seo-primary">Questions</span>
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {[
              {
                question: "How quickly can I expect to see SEO results?",
                answer: "Typically, you'll start seeing initial improvements within 30-60 days, with significant results becoming visible in 3-6 months. The timeline depends on your industry competition and current website status."
              },
              {
                question: "Do you work with businesses outside the US, UK, and Italy?",
                answer: "My primary expertise is in US, UK, and Italian markets, but I can discuss opportunities for other English or Italian-speaking markets on a case-by-case basis."
              },
              {
                question: "What's included in the free SEO audit?",
                answer: "The free audit includes technical SEO analysis, keyword research, competitor analysis, local SEO assessment, and a customized improvement roadmap for your business."
              },
              {
                question: "Do you require long-term contracts?",
                answer: "No, I don't require long-term contracts. I work on a month-to-month basis because I believe in earning your continued business through consistent results and exceptional service."
              },
              {
                question: "How do you measure and report SEO success?",
                answer: "I provide detailed monthly reports showing keyword rankings, organic traffic growth, local visibility improvements, conversion tracking, and ROI analysis with clear, actionable insights."
              },
              {
                question: "Can you help with both local and national SEO?",
                answer: "Yes, I specialize in local SEO but also provide national and international SEO strategies. The approach depends on your business goals and target audience."
              }
            ].map((faq, index) => (
              <Card key={index} className="p-6 hover-lift">
                <CardContent className="p-0">
                  <h3 className="font-poppins font-semibold text-lg mb-3 text-seo-primary" data-testid={`text-faq-${index}-question`}>
                    {faq.question}
                  </h3>
                  <p className="text-gray-600 leading-relaxed" data-testid={`text-faq-${index}-answer`}>
                    {faq.answer}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white text-center" data-testid="section-contact-cta">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-4xl mb-6" data-testid="text-contact-cta-title">
            Ready to Dominate Local Search?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto" data-testid="text-contact-cta-description">
            Don't let your competitors outrank you. Get your FREE SEO audit today and start your journey to the top of search results.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors"
              onClick={openWhatsApp}
              data-testid="button-cta-whatsapp"
            >
              <i className="fab fa-whatsapp mr-2"></i>
              Start WhatsApp Chat
            </Button>
            <Button 
              variant="outline" 
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-seo-primary transition-colors"
              onClick={openWhatsApp}
              data-testid="button-cta-call"
            >
              <i className="fab fa-whatsapp mr-2"></i>
              WhatsApp: 01516089599
            </Button>
          </div>
          <div className="mt-8 text-blue-100">
            <p className="text-sm" data-testid="text-cta-guarantee">
              <i className="fas fa-shield-alt mr-2"></i>
              100% Risk-Free • No Obligation • Quick Response Within 24 Hours
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}