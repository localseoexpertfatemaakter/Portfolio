import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Services() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 gradient-bg text-white" data-testid="section-services-hero">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6" data-testid="text-services-hero-title">
            Professional <span className="text-yellow-300">SEO Services</span>
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8" data-testid="text-services-hero-subtitle">
            Comprehensive SEO solutions designed to boost your local business visibility across US, UK, and Italy markets
          </p>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-20 bg-white" data-testid="section-main-services">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-main-services-title">
              Core SEO <span className="text-seo-primary">Services</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-main-services-description">
              Everything you need to dominate local search results and grow your business online
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            {[
              {
                icon: "fas fa-file-alt",
                title: "On-Page SEO Optimization",
                description: "Comprehensive optimization of your website's content, structure, and HTML elements to improve search engine rankings.",
                features: [
                  "Keyword research and optimization",
                  "Meta titles and descriptions",
                  "Header tag optimization (H1, H2, H3)",
                  "Internal linking strategy",
                  "Content optimization and creation",
                  "Image optimization and alt tags",
                  "URL structure improvement",
                  "Page loading speed optimization"
                ],
                color: "bg-seo-primary",
                price: "Starting from $299/month"
              },
              {
                icon: "fas fa-link", 
                title: "Off-Page SEO & Link Building",
                description: "Strategic link building campaigns to improve your domain authority and search engine credibility.",
                features: [
                  "High-quality backlink acquisition",
                  "Guest posting on relevant sites",
                  "Directory submissions",
                  "Brand mention building",
                  "Social media signals",
                  "Competitor backlink analysis",
                  "Link profile cleanup",
                  "Monthly link building reports"
                ],
                color: "bg-seo-secondary",
                price: "Starting from $399/month"
              },
              {
                icon: "fas fa-map-marker-alt",
                title: "Local SEO & Citation Management", 
                description: "Dominate local search results with comprehensive local SEO strategies tailored to your target market.",
                features: [
                  "Google Business Profile optimization",
                  "Local citation building",
                  "NAP consistency management", 
                  "Local keyword optimization",
                  "Review management strategy",
                  "Local directory submissions",
                  "Location-based content creation",
                  "Local competitor analysis"
                ],
                color: "bg-seo-accent",
                price: "Starting from $349/month"
              },
              {
                icon: "fas fa-store",
                title: "Google Business Profile Optimization",
                description: "Complete optimization of your Google Business Profile to maximize local visibility and customer engagement.",
                features: [
                  "Complete profile setup and optimization",
                  "Category and attribute optimization", 
                  "Photo and video optimization",
                  "Post creation and management",
                  "Q&A management",
                  "Review response management",
                  "Local SEO integration",
                  "Performance tracking and reporting"
                ],
                color: "bg-blue-600",
                price: "Starting from $199/month"
              },
              {
                icon: "fas fa-cog",
                title: "Technical SEO Audit & Optimization",
                description: "Comprehensive technical analysis and optimization to ensure your website meets search engine requirements.",
                features: [
                  "Complete technical SEO audit",
                  "Site speed optimization",
                  "Mobile responsiveness check",
                  "Schema markup implementation",
                  "XML sitemap optimization",
                  "Robots.txt optimization",
                  "SSL certificate setup",
                  "Core Web Vitals improvement"
                ],
                color: "bg-purple-600",
                price: "Starting from $449/month"
              },
              {
                icon: "fas fa-search",
                title: "Keyword Research & Strategy",
                description: "In-depth keyword research and strategic planning to target the most profitable search terms for your business.",
                features: [
                  "Comprehensive keyword research",
                  "Competitor keyword analysis",
                  "Search intent analysis", 
                  "Long-tail keyword identification",
                  "Local keyword research",
                  "Keyword difficulty assessment",
                  "Content gap analysis",
                  "Monthly keyword performance reports"
                ],
                color: "bg-orange-500",
                price: "Starting from $249/month"
              }
            ].map((service, index) => (
              <Card key={index} className="hover-lift">
                <CardContent className="p-8">
                  <div className={`${service.color} text-white w-20 h-20 rounded-full flex items-center justify-center mb-6`}>
                    <i className={`${service.icon} text-3xl`}></i>
                  </div>
                  <h3 className="font-poppins font-bold text-2xl mb-4 text-gray-900" data-testid={`text-service-${index}-title`}>
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-6 leading-relaxed" data-testid={`text-service-${index}-description`}>
                    {service.description}
                  </p>
                  <div className="mb-6">
                    <h4 className="font-semibold text-lg mb-4">What's Included:</h4>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center text-gray-600" data-testid={`text-service-${index}-feature-${featureIndex}`}>
                          <i className="fas fa-check text-seo-secondary mr-3"></i>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-2xl font-bold text-seo-primary" data-testid={`text-service-${index}-price`}>
                      {service.price}
                    </span>
                    <Link href="/contact">
                      <Button className="bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors" data-testid={`button-service-${index}-contact`}>
                        <i className="fas fa-arrow-right mr-2"></i>
                        Get Started
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Region-Specific Services */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-region-services">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-region-services-title">
              Region-Specific <span className="text-seo-primary">SEO Solutions</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-region-services-description">
              Tailored SEO strategies that understand and leverage unique regional market dynamics
            </p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                flag: "🇺🇸",
                title: "United States SEO", 
                description: "Comprehensive SEO services designed for the competitive US market, focusing on local business growth and national visibility.",
                specialties: [
                  "State and city-specific optimization",
                  "Yelp and local directory management", 
                  "US consumer behavior analysis",
                  "Google My Business mastery",
                  "American English content optimization"
                ],
                href: "/us-region",
                buttonColor: "bg-red-500 hover:bg-red-600"
              },
              {
                flag: "🇬🇧",
                title: "United Kingdom SEO",
                description: "Strategic SEO solutions for UK businesses, incorporating British search behaviors and local market preferences.",
                specialties: [
                  "UK-specific directory optimization",
                  "British English content creation",
                  "Trustpilot integration",
                  "Local council website listings",
                  "Brexit-compliant SEO strategies"
                ],
                href: "/uk-region", 
                buttonColor: "bg-blue-600 hover:bg-blue-700"
              },
              {
                flag: "🇮🇹",
                title: "Italy SEO",
                description: "Specialized SEO services for the Italian market, focusing on local culture, language nuances, and regional preferences.",
                specialties: [
                  "Italian language optimization",
                  "Regional Italian directory listings",
                  "Cultural content adaptation",
                  "Italian consumer psychology",
                  "Multi-language SEO implementation"
                ],
                href: "/italy-region",
                buttonColor: "bg-green-600 hover:bg-green-700"
              }
            ].map((region, index) => (
              <Card key={index} className="hover-lift">
                <CardContent className="p-8 text-center">
                  <div className="text-6xl mb-6" data-testid={`text-region-${index}-flag`}>{region.flag}</div>
                  <h3 className="font-poppins font-bold text-2xl mb-4 text-gray-900" data-testid={`text-region-${index}-title`}>
                    {region.title}
                  </h3>
                  <p className="text-gray-600 mb-6" data-testid={`text-region-${index}-description`}>
                    {region.description}
                  </p>
                  <div className="text-left mb-8">
                    <h4 className="font-semibold mb-4">Regional Specialties:</h4>
                    <ul className="space-y-2">
                      {region.specialties.map((specialty, specialtyIndex) => (
                        <li key={specialtyIndex} className="flex items-center text-sm text-gray-600" data-testid={`text-region-${index}-specialty-${specialtyIndex}`}>
                          <i className="fas fa-check text-seo-secondary mr-2"></i>
                          {specialty}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Link href={region.href}>
                    <Button className="w-full bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors" data-testid={`button-region-${index}-explore`}>
                      <i className="fas fa-arrow-right mr-2"></i>
                      Explore {region.title.split(' ')[0]} Services
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Overview */}
      <section className="py-20 bg-white" data-testid="section-process-overview">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-process-title">
              My SEO <span className="text-seo-primary">Process</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-process-description">
              A proven methodology that delivers consistent results for businesses across all industries
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Audit & Analysis",
                description: "Comprehensive analysis of your current SEO status, technical issues, and competitor landscape.",
                icon: "fas fa-search",
                color: "bg-seo-primary"
              },
              {
                step: "02", 
                title: "Strategy Development",
                description: "Custom SEO strategy creation based on your business goals, target audience, and market analysis.",
                icon: "fas fa-lightbulb",
                color: "bg-seo-secondary"
              },
              {
                step: "03",
                title: "Implementation",
                description: "Execute the SEO strategy with on-page optimization, technical fixes, and content creation.",
                icon: "fas fa-tools", 
                color: "bg-seo-accent"
              },
              {
                step: "04",
                title: "Monitor & Optimize",
                description: "Continuous monitoring, reporting, and optimization to ensure maximum ROI and sustained growth.",
                icon: "fas fa-chart-line",
                color: "bg-purple-600"
              }
            ].map((process, index) => (
              <Card key={index} className="text-center hover-lift relative overflow-hidden">
                <CardContent className="p-8">
                  <div className="absolute top-0 right-0 text-8xl font-bold text-gray-100 opacity-30 -mr-4 -mt-4" data-testid={`text-process-${index}-number`}>
                    {process.step}
                  </div>
                  <div className={`${process.color} text-white w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto relative z-10`}>
                    <i className={`${process.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4 relative z-10" data-testid={`text-process-${index}-title`}>
                    {process.title}
                  </h3>
                  <p className="text-gray-600 relative z-10" data-testid={`text-process-${index}-description`}>
                    {process.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Overview */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-pricing-overview">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-pricing-title">
              Transparent <span className="text-seo-primary">Pricing</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-pricing-description">
              Flexible pricing packages designed to fit businesses of all sizes and budgets
            </p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                title: "Starter Package",
                price: "$299",
                period: "/month",
                description: "Perfect for small local businesses getting started with SEO",
                features: [
                  "Basic on-page optimization",
                  "Google Business Profile setup",
                  "5 local citations",
                  "Monthly progress report",
                  "Email support"
                ],
                popular: false,
                buttonColor: "bg-gray-600 hover:bg-gray-700"
              },
              {
                title: "Professional Package",
                price: "$599", 
                period: "/month",
                description: "Comprehensive SEO solution for growing businesses",
                features: [
                  "Complete on-page optimization",
                  "Technical SEO audit & fixes",
                  "15 high-quality backlinks",
                  "20 local citations",
                  "Content creation (2 pages/month)",
                  "Bi-weekly progress reports",
                  "Phone & email support"
                ],
                popular: true,
                buttonColor: "bg-seo-primary hover:bg-blue-600"
              },
              {
                title: "Enterprise Package",
                price: "$999",
                period: "/month", 
                description: "Advanced SEO for established businesses and multiple locations",
                features: [
                  "Full SEO optimization",
                  "Advanced technical SEO",
                  "30 high-quality backlinks",
                  "50 local citations",
                  "Content creation (4 pages/month)",
                  "Weekly progress reports",
                  "Priority phone & email support",
                  "Dedicated account manager"
                ],
                popular: false,
                buttonColor: "bg-seo-secondary hover:bg-green-600"
              }
            ].map((plan, index) => (
              <Card key={index} className={`hover-lift ${plan.popular ? 'ring-2 ring-seo-primary relative' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-seo-primary text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}
                <CardContent className="p-8 text-center">
                  <h3 className="font-poppins font-bold text-2xl mb-4 text-gray-900" data-testid={`text-plan-${index}-title`}>
                    {plan.title}
                  </h3>
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-seo-primary" data-testid={`text-plan-${index}-price`}>{plan.price}</span>
                    <span className="text-gray-600" data-testid={`text-plan-${index}-period`}>{plan.period}</span>
                  </div>
                  <p className="text-gray-600 mb-8" data-testid={`text-plan-${index}-description`}>
                    {plan.description}
                  </p>
                  <ul className="space-y-3 mb-8 text-left">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-gray-600" data-testid={`text-plan-${index}-feature-${featureIndex}`}>
                        <i className="fas fa-check text-seo-secondary mr-3"></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link href="/contact">
                    <Button className="w-full bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors" data-testid={`button-plan-${index}-choose`}>
                      <i className="fas fa-arrow-right mr-2"></i>
                      Choose Plan
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">
              All packages include a 30-day money-back guarantee and no long-term contracts
            </p>
            <Link href="/contact">
              <Button className="bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors" data-testid="button-custom-quote">
                <i className="fas fa-calculator mr-2"></i>
                Get Custom Quote
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white text-center" data-testid="section-services-cta">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-4xl mb-6" data-testid="text-services-cta-title">
            Ready to Boost Your Local Rankings?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto" data-testid="text-services-cta-description">
            Request your FREE SEO audit today and discover how to outrank your competitors
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-services-audit">
                <i className="fas fa-rocket mr-2"></i>
                Request Free SEO Audit
              </Button>
            </Link>
            <Button className="bg-white text-seo-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors" data-testid="button-services-call">
              <i className="fab fa-whatsapp mr-2"></i>
              WhatsApp: 01516089599
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
