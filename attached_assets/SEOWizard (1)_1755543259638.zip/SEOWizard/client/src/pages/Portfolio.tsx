import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Portfolio() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 gradient-bg text-white" data-testid="section-portfolio-hero">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6" data-testid="text-portfolio-hero-title">
            SEO Success <span className="text-yellow-300">Portfolio</span>
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8" data-testid="text-portfolio-hero-subtitle">
            Real results from real businesses across the US, UK, and Italy. See how my proven SEO strategies have transformed local visibility and driven exceptional growth.
          </p>
        </div>
      </section>

      {/* Portfolio Overview */}
      <section className="py-20 bg-white" data-testid="section-portfolio-overview">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-4 gap-8 mb-16">
            {[
              {
                number: "200+",
                label: "Projects Completed",
                icon: "fas fa-chart-line"
              },
              {
                number: "285%",
                label: "Average Traffic Increase",
                icon: "fas fa-arrow-up"
              },
              {
                number: "98%",
                label: "Client Satisfaction Rate",
                icon: "fas fa-heart"
              },
              {
                number: "3",
                label: "Countries Served",
                icon: "fas fa-globe"
              }
            ].map((stat, index) => (
              <Card key={index} className="text-center p-8 hover-lift">
                <CardContent className="p-0">
                  <div className="bg-seo-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className={`${stat.icon} text-2xl`}></i>
                  </div>
                  <div className="text-3xl font-bold text-seo-primary mb-2" data-testid={`text-stat-${index}-number`}>
                    {stat.number}
                  </div>
                  <div className="text-gray-600" data-testid={`text-stat-${index}-label`}>
                    {stat.label}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Projects by Region */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-portfolio-projects">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-projects-title">
              Featured <span className="text-seo-primary">Case Studies</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-projects-description">
              Explore detailed case studies showcasing remarkable SEO transformations across different industries and regions
            </p>
          </div>

          <Tabs defaultValue="us" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-12">
              <TabsTrigger value="us" className="text-lg font-semibold" data-testid="tab-trigger-us">
                🇺🇸 United States
              </TabsTrigger>
              <TabsTrigger value="uk" className="text-lg font-semibold" data-testid="tab-trigger-uk">
                🇬🇧 United Kingdom
              </TabsTrigger>
              <TabsTrigger value="italy" className="text-lg font-semibold" data-testid="tab-trigger-italy">
                🇮🇹 Italy
              </TabsTrigger>
            </TabsList>

            {/* US Projects */}
            <TabsContent value="us" data-testid="tab-content-us">
              <div className="grid lg:grid-cols-2 gap-8">
                {[
                  {
                    title: "Houston Restaurant Chain",
                    location: "Houston, Texas",
                    industry: "Food & Beverage",
                    timeline: "6 months",
                    challenge: "12-location restaurant chain struggling with local visibility and online reservations in competitive Houston market.",
                    solution: "Implemented comprehensive local SEO strategy with Google My Business optimization, local citation building, and review management across all locations.",
                    results: [
                      "285% increase in organic traffic",
                      "150% more online reservations",
                      "#1 ranking for 'best restaurant Houston'",
                      "12 locations optimized and ranked"
                    ],
                    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+285% Traffic"
                  },
                  {
                    title: "Tampa Professional Services",
                    location: "Tampa, Florida",
                    industry: "Professional Services", 
                    timeline: "8 months",
                    challenge: "Local service business facing intense competition and struggling to generate quality leads from organic search.",
                    solution: "Developed targeted keyword strategy, optimized service pages, and built authoritative local backlinks from Tampa business community.",
                    results: [
                      "320% increase in qualified leads",
                      "Top 3 rankings for target keywords",
                      "90% reduction in cost per lead",
                      "150% increase in phone consultations"
                    ],
                    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+320% Leads"
                  },
                  {
                    title: "San Diego Healthcare Practice",
                    location: "San Diego, California",
                    industry: "Healthcare",
                    timeline: "7 months", 
                    challenge: "Medical practice needed to improve online visibility and attract more patients in competitive San Diego healthcare market.",
                    solution: "Implemented medical SEO best practices, optimized for local health searches, and managed online reputation across medical review platforms.",
                    results: [
                      "250% increase in patient inquiries",
                      "Top 5 rankings for medical keywords",
                      "200% growth in appointment bookings",
                      "Expanded service area coverage"
                    ],
                    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+250% Patients"
                  },
                  {
                    title: "NYC Retail Business",
                    location: "New York City, New York",
                    industry: "Retail",
                    timeline: "9 months",
                    challenge: "Small retail business competing against major chains in NYC, struggling with both online and foot traffic.",
                    solution: "Created hyper-local SEO strategy targeting neighborhood-specific keywords and optimized for local e-commerce searches.",
                    results: [
                      "400% increase in online sales",
                      "300% more store visits",
                      "#1 ranking for local retail keywords",
                      "Expanded to 3 additional locations"
                    ],
                    image: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+400% Sales"
                  }
                ].map((project, index) => (
                  <Card key={index} className="hover-lift overflow-hidden">
                    <div className="relative">
                      <img 
                        src={project.image} 
                        alt={project.title}
                        className="w-full h-48 object-cover"
                        data-testid={`img-us-case-${index}`}
                      />
                      <div className="absolute top-4 right-4 bg-seo-secondary text-white px-3 py-1 rounded-full text-sm font-semibold">
                        {project.resultBadge}
                      </div>
                    </div>
                    <CardContent className="p-8">
                      <div className="mb-4">
                        <h3 className="font-poppins font-bold text-2xl mb-2 text-gray-900" data-testid={`text-us-case-${index}-title`}>
                          {project.title}
                        </h3>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                          <span data-testid={`text-us-case-${index}-location`}>
                            <i className="fas fa-map-marker-alt mr-1"></i>
                            {project.location}
                          </span>
                          <span data-testid={`text-us-case-${index}-industry`}>
                            <i className="fas fa-industry mr-1"></i>
                            {project.industry}
                          </span>
                          <span data-testid={`text-us-case-${index}-timeline`}>
                            <i className="fas fa-clock mr-1"></i>
                            {project.timeline}
                          </span>
                        </div>
                      </div>
                      
                      <div className="space-y-6">
                        <div>
                          <h4 className="font-semibold text-lg mb-2 text-red-600">Challenge</h4>
                          <p className="text-gray-600" data-testid={`text-us-case-${index}-challenge`}>
                            {project.challenge}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold text-lg mb-2 text-blue-600">Solution</h4>
                          <p className="text-gray-600" data-testid={`text-us-case-${index}-solution`}>
                            {project.solution}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold text-lg mb-3 text-seo-secondary">Results</h4>
                          <ul className="space-y-2">
                            {project.results.map((result, resultIndex) => (
                              <li key={resultIndex} className="flex items-center text-gray-600" data-testid={`text-us-case-${index}-result-${resultIndex}`}>
                                <i className="fas fa-check text-seo-secondary mr-3"></i>
                                {result}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* UK Projects */}
            <TabsContent value="uk" data-testid="tab-content-uk">
              <div className="grid lg:grid-cols-2 gap-8">
                {[
                  {
                    title: "London Law Firm",
                    location: "London, England",
                    industry: "Legal Services",
                    timeline: "8 months",
                    challenge: "Prestigious law firm needed to compete with larger firms for high-value legal keywords in competitive London market.",
                    solution: "Developed content-driven SEO strategy focusing on legal expertise, local authority building, and thought leadership positioning.",
                    results: [
                      "320% increase in qualified leads",
                      "Top 3 rankings for legal keywords",
                      "150% increase in consultation requests", 
                      "85% reduction in cost per lead"
                    ],
                    image: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+320% Leads"
                  },
                  {
                    title: "Birmingham Healthcare Network",
                    location: "Birmingham, England", 
                    industry: "Healthcare",
                    timeline: "6 months",
                    challenge: "Multi-location healthcare practice struggling with local visibility across Birmingham and West Midlands region.",
                    solution: "Implemented location-specific SEO strategy with individual landing pages, local schema markup, and NHS directory optimization.",
                    results: [
                      "280% increase in patient bookings",
                      "Top 5 rankings for medical keywords",
                      "200% growth in online appointments",
                      "Expanded to West Midlands coverage"
                    ],
                    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+280% Bookings"
                  },
                  {
                    title: "Manchester Restaurant Group",
                    location: "Manchester, England",
                    industry: "Food & Beverage",
                    timeline: "7 months",
                    challenge: "Restaurant group facing declining reservations and poor online visibility in competitive Manchester dining scene.",
                    solution: "Created comprehensive local SEO strategy with Google My Business optimization, local food blogger outreach, and review management.",
                    results: [
                      "350% increase in reservations",
                      "300% more online bookings",
                      "#1 ranking for 'best restaurant Manchester'",
                      "Expanded to 4 additional locations"
                    ],
                    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+350% Reservations"
                  },
                  {
                    title: "Oxford Professional Services",
                    location: "Oxford, England",
                    industry: "Professional Services",
                    timeline: "9 months",
                    challenge: "Professional services firm needed to establish authority and generate leads in prestigious Oxford market with educated clientele.",
                    solution: "Developed expertise-focused content strategy with local university partnerships and thought leadership positioning.",
                    results: [
                      "290% increase in client inquiries",
                      "Top 3 rankings for service keywords",
                      "250% increase in phone consultations",
                      "Expanded service area to surrounding counties"
                    ],
                    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+290% Inquiries"
                  }
                ].map((project, index) => (
                  <Card key={index} className="hover-lift overflow-hidden">
                    <div className="relative">
                      <img 
                        src={project.image} 
                        alt={project.title}
                        className="w-full h-48 object-cover"
                        data-testid={`img-uk-case-${index}`}
                      />
                      <div className="absolute top-4 right-4 bg-seo-secondary text-white px-3 py-1 rounded-full text-sm font-semibold">
                        {project.resultBadge}
                      </div>
                    </div>
                    <CardContent className="p-8">
                      <div className="mb-4">
                        <h3 className="font-poppins font-bold text-2xl mb-2 text-gray-900" data-testid={`text-uk-case-${index}-title`}>
                          {project.title}
                        </h3>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                          <span data-testid={`text-uk-case-${index}-location`}>
                            <i className="fas fa-map-marker-alt mr-1"></i>
                            {project.location}
                          </span>
                          <span data-testid={`text-uk-case-${index}-industry`}>
                            <i className="fas fa-industry mr-1"></i>
                            {project.industry}
                          </span>
                          <span data-testid={`text-uk-case-${index}-timeline`}>
                            <i className="fas fa-clock mr-1"></i>
                            {project.timeline}
                          </span>
                        </div>
                      </div>
                      
                      <div className="space-y-6">
                        <div>
                          <h4 className="font-semibold text-lg mb-2 text-red-600">Challenge</h4>
                          <p className="text-gray-600" data-testid={`text-uk-case-${index}-challenge`}>
                            {project.challenge}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold text-lg mb-2 text-blue-600">Solution</h4>
                          <p className="text-gray-600" data-testid={`text-uk-case-${index}-solution`}>
                            {project.solution}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold text-lg mb-3 text-seo-secondary">Results</h4>
                          <ul className="space-y-2">
                            {project.results.map((result, resultIndex) => (
                              <li key={resultIndex} className="flex items-center text-gray-600" data-testid={`text-uk-case-${index}-result-${resultIndex}`}>
                                <i className="fas fa-check text-seo-secondary mr-3"></i>
                                {result}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Italy Projects */}
            <TabsContent value="italy" data-testid="tab-content-italy">
              <div className="grid lg:grid-cols-2 gap-8">
                {[
                  {
                    title: "Milan Fashion Boutique",
                    location: "Milano, Lombardia",
                    industry: "Fashion & Retail",
                    timeline: "5 months",
                    challenge: "High-end fashion boutique struggling to compete with major brands in Milan's competitive fashion district.",
                    solution: "Implemented luxury brand SEO strategy with Italian fashion keywords, local influencer partnerships, and visual search optimization.",
                    results: [
                      "250% increase in online sales",
                      "300% more store visits", 
                      "#1 ranking for 'boutique Milano'",
                      "Expanded to 2 additional locations"
                    ],
                    image: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+250% Sales"
                  },
                  {
                    title: "Rome Restaurant Empire",
                    location: "Roma, Lazio",
                    industry: "Food & Beverage",
                    timeline: "6 months",
                    challenge: "Traditional Roman restaurant group facing competition from modern establishments and declining tourist traffic.",
                    solution: "Developed multi-language SEO strategy targeting both local Romans and international tourists with authentic Italian dining experience.",
                    results: [
                      "380% increase in reservations",
                      "350% more online bookings",
                      "#1 ranking for 'miglior ristorante Roma'",
                      "Expanded to 5 additional locations"
                    ],
                    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+380% Prenotazioni"
                  },
                  {
                    title: "Florence Tourism Experience",
                    location: "Firenze, Toscana",
                    industry: "Tourism & Hospitality",
                    timeline: "7 months",
                    challenge: "Tourism business needed to differentiate from generic tour operators and attract quality international visitors to Florence.",
                    solution: "Created authentic Tuscan experience SEO strategy with cultural content, multi-language optimization, and partnership with local artisans.",
                    results: [
                      "290% increase in tourist bookings",
                      "Top 3 rankings for tourism keywords",
                      "250% increase in tour reservations",
                      "Expanded to Venice and Rome tours"
                    ],
                    image: "https://images.unsplash.com/photo-1543832923-44667a44c804?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+290% Bookings"
                  },
                  {
                    title: "Naples Professional Hub",
                    location: "Napoli, Campania",
                    industry: "Professional Services",
                    timeline: "8 months",
                    challenge: "Professional services firm in Southern Italy needed to establish credibility and expand client base in competitive market.",
                    solution: "Built authority through local business network partnerships, Italian professional directory optimization, and regional content strategy.",
                    results: [
                      "270% increase in consultations",
                      "Top 5 rankings for service keywords",
                      "200% increase in phone inquiries",
                      "Expanded service area to Campania region"
                    ],
                    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
                    resultBadge: "+270% Consultazioni"
                  }
                ].map((project, index) => (
                  <Card key={index} className="hover-lift overflow-hidden">
                    <div className="relative">
                      <img 
                        src={project.image} 
                        alt={project.title}
                        className="w-full h-48 object-cover"
                        data-testid={`img-italy-case-${index}`}
                      />
                      <div className="absolute top-4 right-4 bg-seo-secondary text-white px-3 py-1 rounded-full text-sm font-semibold">
                        {project.resultBadge}
                      </div>
                    </div>
                    <CardContent className="p-8">
                      <div className="mb-4">
                        <h3 className="font-poppins font-bold text-2xl mb-2 text-gray-900" data-testid={`text-italy-case-${index}-title`}>
                          {project.title}
                        </h3>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                          <span data-testid={`text-italy-case-${index}-location`}>
                            <i className="fas fa-map-marker-alt mr-1"></i>
                            {project.location}
                          </span>
                          <span data-testid={`text-italy-case-${index}-industry`}>
                            <i className="fas fa-industry mr-1"></i>
                            {project.industry}
                          </span>
                          <span data-testid={`text-italy-case-${index}-timeline`}>
                            <i className="fas fa-clock mr-1"></i>
                            {project.timeline}
                          </span>
                        </div>
                      </div>
                      
                      <div className="space-y-6">
                        <div>
                          <h4 className="font-semibold text-lg mb-2 text-red-600">Sfida</h4>
                          <p className="text-gray-600" data-testid={`text-italy-case-${index}-challenge`}>
                            {project.challenge}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold text-lg mb-2 text-blue-600">Soluzione</h4>
                          <p className="text-gray-600" data-testid={`text-italy-case-${index}-solution`}>
                            {project.solution}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold text-lg mb-3 text-seo-secondary">Risultati</h4>
                          <ul className="space-y-2">
                            {project.results.map((result, resultIndex) => (
                              <li key={resultIndex} className="flex items-center text-gray-600" data-testid={`text-italy-case-${index}-result-${resultIndex}`}>
                                <i className="fas fa-check text-seo-secondary mr-3"></i>
                                {result}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Process Showcase */}
      <section className="py-20 bg-white" data-testid="section-portfolio-process">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-process-showcase-title">
              My Proven <span className="text-seo-primary">SEO Process</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-process-showcase-description">
              The same methodology behind every successful case study
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Deep Analysis",
                description: "Comprehensive audit of current SEO performance, competitor analysis, and market research.",
                icon: "fas fa-search",
                color: "bg-seo-primary"
              },
              {
                step: "02",
                title: "Strategic Planning",
                description: "Custom SEO roadmap based on business goals, target audience, and competitive landscape.",
                icon: "fas fa-lightbulb",
                color: "bg-seo-secondary"
              },
              {
                step: "03",
                title: "Expert Implementation",
                description: "Systematic execution of on-page, off-page, and technical SEO optimizations.",
                icon: "fas fa-tools",
                color: "bg-seo-accent"
              },
              {
                step: "04",
                title: "Continuous Growth",
                description: "Ongoing monitoring, optimization, and strategy refinement for sustained results.",
                icon: "fas fa-chart-line",
                color: "bg-purple-600"
              }
            ].map((step, index) => (
              <Card key={index} className="text-center hover-lift relative overflow-hidden">
                <CardContent className="p-8">
                  <div className="absolute top-0 right-0 text-6xl font-bold text-gray-100 opacity-30 -mr-2 -mt-2">
                    {step.step}
                  </div>
                  <div className={`${step.color} text-white w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto relative z-10`}>
                    <i className={`${step.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4 relative z-10" data-testid={`text-process-step-${index}-title`}>
                    {step.title}
                  </h3>
                  <p className="text-gray-600 relative z-10" data-testid={`text-process-step-${index}-description`}>
                    {step.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white text-center" data-testid="section-portfolio-cta">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-4xl mb-6" data-testid="text-portfolio-cta-title">
            Ready to Be My Next Success Story?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto" data-testid="text-portfolio-cta-description">
            Join the 200+ businesses that have transformed their online presence with my proven SEO strategies
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-portfolio-cta-contact">
                <i className="fas fa-rocket mr-2"></i>
                Start Your SEO Journey
              </Button>
            </Link>
            <Link href="/services">
              <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-seo-primary transition-colors" data-testid="button-portfolio-cta-services">
                <i className="fas fa-list mr-2"></i>
                View All Services
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
