import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="gradient-bg min-h-screen flex items-center" data-testid="section-hero">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6 leading-tight" data-testid="text-hero-title">
                Top Local SEO Expert – 
                <span className="text-yellow-300">US, UK & Italy</span>
              </h1>
              <p className="text-xl mb-8 text-blue-100 leading-relaxed" data-testid="text-hero-subtitle">
                Boost Your Local Business Visibility Today with Proven SEO Strategies That Drive Real Results
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Link href="/contact">
                  <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 hover:scale-105 hover:shadow-2xl transition-all duration-300 transform" data-testid="button-hero-contact">
                    <i className="fas fa-rocket mr-2"></i>
                    Get Free SEO Audit
                  </Button>
                </Link>
                <Link href="/services">
                  <Button className="bg-white text-seo-primary border-2 border-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-seo-primary hover:text-white hover:scale-105 hover:shadow-2xl transition-all duration-300 transform" data-testid="button-hero-services">
                    <i className="fas fa-search mr-2"></i>
                    View Services
                  </Button>
                </Link>
              </div>
              <div className="flex items-center mt-8 text-blue-100">
                <div className="flex -space-x-2 mr-4">
                  <div className="w-10 h-10 bg-yellow-400 rounded-full border-2 border-white flex items-center justify-center">
                    <i className="fas fa-star text-white text-sm"></i>
                  </div>
                  <div className="w-10 h-10 bg-yellow-400 rounded-full border-2 border-white flex items-center justify-center">
                    <i className="fas fa-star text-white text-sm"></i>
                  </div>
                  <div className="w-10 h-10 bg-yellow-400 rounded-full border-2 border-white flex items-center justify-center">
                    <i className="fas fa-star text-white text-sm"></i>
                  </div>
                </div>
                <span className="text-sm" data-testid="text-hero-trust">Trusted by 200+ businesses across 3 countries</span>
              </div>
            </div>
            <div className="relative">
              <div className="relative z-10">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                  alt="SEO Analytics Dashboard" 
                  className="rounded-xl shadow-lg w-full"
                  data-testid="image-seo-dashboard"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-about-preview">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Digital Marketing Strategy" 
                className="rounded-xl shadow-lg w-full"
                data-testid="img-about-strategy"
              />
            </div>
            <div>
              <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-about-title">
                About <span className="text-seo-primary">Fatema Akter</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed" data-testid="text-about-description">
                I'm a dedicated Local SEO Expert with over 5 years of experience helping businesses across the US, UK, and Italy dominate their local markets. My proven strategies have generated millions in revenue for clients through improved search visibility and local rankings.
              </p>
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-seo-primary" data-testid="text-stat-projects">200+</div>
                  <div className="text-gray-600">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-seo-primary" data-testid="text-stat-countries">3</div>
                  <div className="text-gray-600">Countries Served</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-seo-primary" data-testid="text-stat-satisfaction">98%</div>
                  <div className="text-gray-600">Client Satisfaction</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-seo-primary" data-testid="text-stat-experience">5+</div>
                  <div className="text-gray-600">Years Experience</div>
                </div>
              </div>
              <Link href="/about">
                <Button className="bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-600 transition-colors" data-testid="button-learn-more">
                  <i className="fas fa-user-tie mr-2"></i>
                  Learn More About Me
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview Section */}
      <section className="py-20 bg-white" data-testid="section-services-overview">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-services-title">
              Professional <span className="text-seo-primary">SEO Services</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-services-description">
              Comprehensive SEO solutions tailored for businesses in the US, UK, and Italy. Drive more traffic, leads, and sales with proven local SEO strategies.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: "fas fa-file-alt",
                title: "On-Page SEO",
                description: "Optimize your website content, meta tags, headings, and internal linking structure for maximum search visibility.",
                features: ["Content Optimization", "Meta Tag Enhancement", "Internal Link Strategy"],
                color: "bg-seo-primary"
              },
              {
                icon: "fas fa-link",
                title: "Off-Page SEO", 
                description: "Build high-quality backlinks and improve your domain authority through strategic link building campaigns.",
                features: ["Quality Link Building", "Guest Posting", "Brand Mentions"],
                color: "bg-seo-secondary"
              },
              {
                icon: "fas fa-map-marker-alt",
                title: "Local SEO",
                description: "Dominate local search results with optimized Google Business Profile and local citation management.",
                features: ["Google Business Profile", "Local Citations", "Review Management"],
                color: "bg-seo-accent"
              },
              {
                icon: "fas fa-cog",
                title: "Technical SEO",
                description: "Fix technical issues that hinder your site's performance and search engine crawlability.",
                features: ["Site Speed Optimization", "Mobile Responsiveness", "Schema Markup"],
                color: "bg-purple-600"
              }
            ].map((service, index) => (
              <Card key={index} className="hover-lift">
                <CardContent className="p-8 text-center">
                  <div className={`${service.color} text-white w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto`}>
                    <i className={`${service.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4" data-testid={`text-service-${index}-title`}>{service.title}</h3>
                  <p className="text-gray-600 mb-6" data-testid={`text-service-${index}-description`}>
                    {service.description}
                  </p>
                  <ul className="text-sm text-gray-600 space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} data-testid={`text-service-${index}-feature-${featureIndex}`}>
                        <i className="fas fa-check text-seo-secondary mr-2"></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/services">
              <Button className="bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors" data-testid="button-view-all-services">
                <i className="fas fa-arrow-right mr-2"></i>
                View All Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Region Highlights Section */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-region-highlights">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-regions-title">
              Regional <span className="text-seo-primary">Expertise</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-regions-description">
              Specialized local SEO services tailored for each region's unique market dynamics and search behaviors.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                flag: "🇺🇸",
                title: "United States",
                features: ["50+ Cities Covered", "Google My Business Optimization", "Local Directory Listings", "Yelp & Review Management"],
                color: "border-red-500",
                buttonColor: "bg-red-500 hover:bg-red-600",
                href: "/us-region"
              },
              {
                flag: "🇬🇧", 
                title: "United Kingdom",
                features: ["Major UK Cities", "Local SEO Compliance", "UK Business Directories", "Trustpilot Integration"],
                color: "border-blue-600",
                buttonColor: "bg-blue-600 hover:bg-blue-700",
                href: "/uk-region"
              },
              {
                flag: "🇮🇹",
                title: "Italy", 
                features: ["Italian Market Expertise", "Local Citation Building", "Regional Directory Optimization", "Multi-language SEO"],
                color: "border-green-600",
                buttonColor: "bg-green-600 hover:bg-green-700",
                href: "/italy-region"
              }
            ].map((region, index) => (
              <Card key={index} className={`hover-lift border-t-4 ${region.color}`}>
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className="text-6xl mb-4" data-testid={`text-region-${index}-flag`}>{region.flag}</div>
                    <h3 className="font-poppins font-bold text-2xl text-gray-900" data-testid={`text-region-${index}-title`}>{region.title}</h3>
                  </div>
                  <div className="space-y-4 mb-8">
                    {region.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center" data-testid={`text-region-${index}-feature-${featureIndex}`}>
                        <i className="fas fa-check-circle text-seo-secondary mr-3"></i>
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                  <Link href={region.href}>
                    <Button className={`w-full ${region.buttonColor} text-white py-3 rounded-lg font-semibold transition-colors`} data-testid={`button-explore-${region.title.toLowerCase().replace(' ', '-')}`}>
                      Explore {region.title} Services
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Preview Section */}
      <section className="py-20 bg-white" data-testid="section-portfolio-preview">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-portfolio-title">
              Success <span className="text-seo-primary">Stories</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-portfolio-description">
              Real results from real businesses. See how our SEO strategies have transformed local visibility and driven growth.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
                alt: "SEO Keyword Research Results",
                region: "🇺🇸 US",
                regionColor: "bg-red-500", 
                result: "+285% Traffic",
                title: "Houston Restaurant Chain",
                description: "Increased local search visibility for a Houston-based restaurant chain across 12 locations, resulting in 285% traffic increase and 150% more reservations.",
                duration: "6 months",
                location: "Houston, TX"
              },
              {
                image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
                alt: "Website Optimization Tools",
                region: "🇬🇧 UK",
                regionColor: "bg-blue-600",
                result: "+320% Leads", 
                title: "London Law Firm",
                description: "Transformed online presence for a London law firm, achieving top 3 rankings for competitive legal keywords and generating 320% more qualified leads.",
                duration: "8 months",
                location: "London, UK"
              },
              {
                image: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250", 
                alt: "Local Business SEO Optimization",
                region: "🇮🇹 Italy",
                regionColor: "bg-green-600",
                result: "+250% Sales",
                title: "Milan Fashion Boutique", 
                description: "Boosted online visibility for a Milan fashion boutique, achieving first page rankings for local fashion keywords and increasing online sales by 250%.",
                duration: "5 months",
                location: "Milan, Italy"
              }
            ].map((project, index) => (
              <Card key={index} className="hover-lift overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.alt} 
                  className="w-full h-48 object-cover"
                  data-testid={`img-portfolio-${index}`}
                />
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <span className={`${project.regionColor} text-white px-3 py-1 rounded-full text-sm font-semibold`} data-testid={`text-portfolio-${index}-region`}>
                      {project.region}
                    </span>
                    <span className="ml-2 text-seo-secondary font-semibold" data-testid={`text-portfolio-${index}-result`}>
                      {project.result}
                    </span>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-3" data-testid={`text-portfolio-${index}-title`}>
                    {project.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4" data-testid={`text-portfolio-${index}-description`}>
                    {project.description}
                  </p>
                  <div className="flex justify-between text-sm text-gray-500">
                    <span data-testid={`text-portfolio-${index}-duration`}>
                      <i className="fas fa-calendar mr-1"></i>
                      {project.duration}
                    </span>
                    <span data-testid={`text-portfolio-${index}-location`}>
                      <i className="fas fa-map-marker-alt mr-1"></i>
                      {project.location}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/portfolio">
              <Button className="bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors" data-testid="button-view-portfolio">
                <i className="fas fa-eye mr-2"></i>
                View Full Portfolio
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Preview Section */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-testimonials-preview">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-testimonials-title">
              Client <span className="text-seo-primary">Testimonials</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-testimonials-description">
              Hear what our satisfied clients across the US, UK, and Italy have to say about their SEO success.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                initial: "M",
                name: "Michael Johnson", 
                title: "Restaurant Owner, Houston 🇺🇸",
                bgColor: "bg-red-500",
                testimonial: "Fatema transformed our online presence completely. We went from page 3 to #1 for 'best restaurant Houston' in just 4 months. Our reservations increased by 150%!"
              },
              {
                initial: "S",
                name: "Sarah Thompson",
                title: "Law Firm Partner, London 🇬🇧", 
                bgColor: "bg-blue-600",
                testimonial: "Outstanding results! Our firm now ranks #1 for competitive legal keywords in London. The quality of leads has improved dramatically, and our client base has grown by 300%."
              },
              {
                initial: "G", 
                name: "Giuseppe Rossi",
                title: "Boutique Owner, Milan 🇮🇹",
                bgColor: "bg-green-600",
                testimonial: "Fantastico! Fatema understood the Italian market perfectly. Our online sales increased by 250% and we're now the top-ranked fashion boutique in Milan for local searches."
              }
            ].map((testimonial, index) => (
              <Card key={index} className="p-8">
                <CardContent className="p-0">
                  <div className="flex items-center mb-6">
                    <div className={`w-12 h-12 ${testimonial.bgColor} rounded-full flex items-center justify-center text-white font-bold text-xl`}>
                      {testimonial.initial}
                    </div>
                    <div className="ml-4">
                      <div className="font-semibold" data-testid={`text-testimonial-${index}-name`}>{testimonial.name}</div>
                      <div className="text-sm text-gray-600" data-testid={`text-testimonial-${index}-title`}>{testimonial.title}</div>
                    </div>
                  </div>
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <i key={i} className="fas fa-star"></i>
                    ))}
                  </div>
                  <p className="text-gray-600 italic mb-4" data-testid={`text-testimonial-${index}-content`}>
                    "{testimonial.testimonial}"
                  </p>
                  <div className="text-sm text-gray-500">
                    <i className="fas fa-quote-right"></i>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/testimonials">
              <Button className="bg-seo-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors" data-testid="button-read-testimonials">
                <i className="fas fa-comments mr-2"></i>
                Read More Testimonials
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Me Section */}
      <section className="py-20 bg-white" data-testid="section-why-choose">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-why-choose-title">
              Why Choose <span className="text-seo-primary">Fatema Akter</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-why-choose-description">
              Experience the difference of working with a dedicated SEO expert who delivers measurable results.
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {[
              {
                icon: "fas fa-chart-line",
                title: "Proven Results",
                description: "Track record of increasing organic traffic by 200-400% and improving local rankings for competitive keywords.",
                color: "bg-seo-primary"
              },
              {
                icon: "fas fa-globe",
                title: "Region Expertise", 
                description: "Deep understanding of local search behaviors and market dynamics in the US, UK, and Italy markets.",
                color: "bg-seo-secondary"
              },
              {
                icon: "fas fa-chart-bar",
                title: "Transparent Reporting",
                description: "Monthly detailed reports showing keyword rankings, traffic growth, and ROI with clear metrics and insights.",
                color: "bg-seo-accent"
              },
              {
                icon: "fas fa-dollar-sign", 
                title: "Affordable Packages",
                description: "Competitive pricing with flexible packages designed to fit businesses of all sizes and budgets.",
                color: "bg-purple-600"
              }
            ].map((reason, index) => (
              <div key={index} className="text-center">
                <div className={`${reason.color} text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6`}>
                  <i className={`${reason.icon} text-3xl`}></i>
                </div>
                <h3 className="font-poppins font-semibold text-xl mb-4" data-testid={`text-reason-${index}-title`}>{reason.title}</h3>
                <p className="text-gray-600" data-testid={`text-reason-${index}-description`}>
                  {reason.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call-to-Action Section */}
      <section className="py-20 gradient-bg" data-testid="section-cta">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-poppins font-bold text-4xl lg:text-5xl mb-6 text-white" data-testid="text-cta-title">
            Ready to Dominate Local Search?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto" data-testid="text-cta-description">
            Get your FREE SEO audit today and discover how to outrank your competitors in local search results. Let's grow your business together!
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link href="/contact">
              <Button className="bg-seo-secondary text-white px-10 py-5 rounded-lg font-semibold text-lg hover:bg-green-600 hover:scale-105 hover:shadow-2xl transition-all duration-300 transform" data-testid="button-cta-audit">
                <i className="fas fa-rocket mr-3"></i>
                Request Your Free SEO Audit Today
              </Button>
            </Link>
            <Button variant="outline" className="border-2 border-white text-white px-8 py-5 rounded-lg font-semibold text-lg hover:bg-white hover:text-seo-primary hover:scale-105 hover:shadow-2xl transition-all duration-300 transform" data-testid="button-cta-call">
              <i className="fas fa-phone mr-3"></i>
              Call: 01516089599
            </Button>
          </div>
          <div className="mt-8 text-blue-100">
            <p className="text-sm" data-testid="text-cta-guarantee">
              <i className="fas fa-shield-alt mr-2"></i>
              100% Risk-Free • No Obligation • Quick Response Within 24 Hours
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}