import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Testimonials() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 gradient-bg text-white" data-testid="section-testimonials-hero">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-poppins font-bold text-4xl lg:text-6xl mb-6" data-testid="text-testimonials-hero-title">
            Client <span className="text-yellow-300">Testimonials</span>
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8" data-testid="text-testimonials-hero-subtitle">
            Hear from satisfied clients across the US, UK, and Italy who have achieved remarkable success with my SEO services
          </p>
        </div>
      </section>

      {/* Testimonials Overview */}
      <section className="py-20 bg-white" data-testid="section-testimonials-overview">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-4 gap-8 mb-16">
            {[
              {
                number: "98%",
                label: "Client Satisfaction",
                icon: "fas fa-heart"
              },
              {
                number: "200+",
                label: "Happy Clients",
                icon: "fas fa-users"
              },
              {
                number: "5.0",
                label: "Average Rating",
                icon: "fas fa-star"
              },
              {
                number: "95%",
                label: "Retention Rate",
                icon: "fas fa-handshake"
              }
            ].map((stat, index) => (
              <Card key={index} className="text-center p-8 hover-lift">
                <CardContent className="p-0">
                  <div className="bg-seo-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className={`${stat.icon} text-2xl`}></i>
                  </div>
                  <div className="text-3xl font-bold text-seo-primary mb-2" data-testid={`text-overview-stat-${index}-number`}>
                    {stat.number}
                  </div>
                  <div className="text-gray-600" data-testid={`text-overview-stat-${index}-label`}>
                    {stat.label}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials by Region */}
      <section className="py-20 bg-seo-gray-50" data-testid="section-testimonials-regions">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-testimonials-regions-title">
              Success Stories by <span className="text-seo-primary">Region</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-testimonials-regions-description">
              Authentic feedback from real clients who have experienced transformational growth
            </p>
          </div>

          <Tabs defaultValue="us" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-12">
              <TabsTrigger value="us" className="text-lg font-semibold" data-testid="tab-trigger-testimonials-us">
                🇺🇸 United States
              </TabsTrigger>
              <TabsTrigger value="uk" className="text-lg font-semibold" data-testid="tab-trigger-testimonials-uk">
                🇬🇧 United Kingdom
              </TabsTrigger>
              <TabsTrigger value="italy" className="text-lg font-semibold" data-testid="tab-trigger-testimonials-italy">
                🇮🇹 Italy
              </TabsTrigger>
            </TabsList>

            {/* US Testimonials */}
            <TabsContent value="us" data-testid="tab-content-testimonials-us">
              <div className="grid lg:grid-cols-2 gap-8">
                {[
                  {
                    name: "Michael Johnson",
                    title: "Restaurant Owner",
                    company: "Houston Bistro Group",
                    location: "Houston, Texas",
                    rating: 5,
                    testimonial: "Fatema transformed our online presence completely. We went from page 3 to #1 for 'best restaurant Houston' in just 4 months. Our reservations increased by 150% and we're now the go-to restaurant in our area. Her understanding of the US market is exceptional!",
                    results: ["285% traffic increase", "150% more reservations", "#1 local ranking"],
                    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Jennifer Rodriguez",
                    title: "Healthcare Administrator", 
                    company: "Tampa Medical Center",
                    location: "Tampa, Florida",
                    rating: 5,
                    testimonial: "Outstanding results! Our medical practice now dominates local search in Tampa. Patient inquiries have tripled, and we're consistently ranked in the top 3 for all our target keywords. Fatema's expertise in healthcare SEO is unmatched. Worth every penny!",
                    results: ["320% more patient inquiries", "Top 3 rankings", "90% cost reduction"],
                    image: "https://images.unsplash.com/photo-1494790108755-2616c0763c7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "David Chen",
                    title: "Retail Business Owner",
                    company: "San Diego Electronics",
                    location: "San Diego, California",
                    rating: 5,
                    testimonial: "Amazing expertise in US local SEO! Fatema helped us grow from a single store to 3 locations in just 8 months. Our online sales increased by 400% and foot traffic doubled. Her strategies are data-driven and results-focused. Highly recommended!",
                    results: ["400% online sales growth", "3 new locations", "300% store visits"],
                    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Sarah Williams",
                    title: "Marketing Director",
                    company: "NYC Professional Services",
                    location: "New York City, New York",
                    rating: 5,
                    testimonial: "Working with Fatema was a game-changer for our NYC business. In the most competitive market in America, she got us to #1 for our main keywords. Our lead quality improved dramatically, and our client acquisition cost dropped by 75%. Simply the best SEO expert we've worked with!",
                    results: ["#1 NYC rankings", "75% cost reduction", "500% lead quality improvement"],
                    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Robert Taylor",
                    title: "Law Firm Partner",
                    company: "Chicago Legal Associates", 
                    location: "Chicago, Illinois",
                    rating: 5,
                    testimonial: "Fatema's SEO expertise helped our law firm achieve unprecedented growth in Chicago. We went from struggling to compete to dominating local legal searches. Our case inquiries increased by 400%, and we've hired 5 additional attorneys to handle the increased caseload.",
                    results: ["400% case inquiries", "5 new attorney hires", "Market domination"],
                    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Lisa Anderson",
                    title: "Dental Practice Owner",
                    company: "Miami Dental Excellence",
                    location: "Miami, Florida",
                    rating: 5,
                    testimonial: "Incredible results! Our dental practice was struggling to get new patients despite being in a prime Miami location. Fatema's local SEO strategy brought us 250% more patient appointments and we're now booked solid for months in advance. Best investment we've ever made!",
                    results: ["250% more appointments", "Fully booked schedule", "Prime local visibility"],
                    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  }
                ].map((testimonial, index) => (
                  <Card key={index} className="p-8 hover-lift">
                    <CardContent className="p-0">
                      <div className="flex items-center mb-6">
                        <img 
                          src={testimonial.image} 
                          alt={testimonial.name}
                          className="w-16 h-16 rounded-full object-cover mr-4"
                          data-testid={`img-us-testimonial-${index}`}
                        />
                        <div>
                          <div className="font-semibold text-lg" data-testid={`text-us-testimonial-${index}-name`}>
                            {testimonial.name}
                          </div>
                          <div className="text-sm text-gray-600" data-testid={`text-us-testimonial-${index}-title`}>
                            {testimonial.title}
                          </div>
                          <div className="text-sm text-seo-primary font-semibold" data-testid={`text-us-testimonial-${index}-company`}>
                            {testimonial.company}
                          </div>
                          <div className="text-xs text-gray-500" data-testid={`text-us-testimonial-${index}-location`}>
                            <i className="fas fa-map-marker-alt mr-1"></i>
                            {testimonial.location}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex text-yellow-400 mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <i key={i} className="fas fa-star"></i>
                        ))}
                      </div>
                      
                      <p className="text-gray-600 italic mb-6 leading-relaxed" data-testid={`text-us-testimonial-${index}-content`}>
                        "{testimonial.testimonial}"
                      </p>
                      
                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-2 text-seo-secondary">Key Results:</h4>
                        <div className="flex flex-wrap gap-2">
                          {testimonial.results.map((result, resultIndex) => (
                            <span 
                              key={resultIndex}
                              className="bg-seo-gray-50 text-seo-primary px-3 py-1 rounded-full text-sm font-semibold"
                              data-testid={`text-us-testimonial-${index}-result-${resultIndex}`}
                            >
                              {result}
                            </span>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* UK Testimonials */}
            <TabsContent value="uk" data-testid="tab-content-testimonials-uk">
              <div className="grid lg:grid-cols-2 gap-8">
                {[
                  {
                    name: "Sarah Thompson",
                    title: "Law Firm Partner",
                    company: "Thompson & Associates",
                    location: "London, England",
                    rating: 5,
                    testimonial: "Outstanding results! Our firm now ranks #1 for competitive legal keywords in London. The quality of leads has improved dramatically, and our client base has grown by 300%. Fatema truly understands the UK market and legal industry. Absolutely brilliant work!",
                    results: ["#1 London rankings", "300% client growth", "Premium lead quality"],
                    image: "https://images.unsplash.com/photo-1494790108755-2616c0763c7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "James Richardson",
                    title: "Healthcare Director",
                    company: "Birmingham Health Group",
                    location: "Birmingham, England",
                    rating: 5,
                    testimonial: "Brilliant work! Our healthcare practice now dominates local search in Birmingham. Patient bookings have increased by 280%, and we're consistently ranked in the top 3 for all our medical keywords. Fatema's understanding of UK healthcare regulations and patient behaviour is exceptional. Highly professional service.",
                    results: ["280% patient bookings", "Top 3 medical rankings", "Regulatory compliance"],
                    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Emma Wilson",
                    title: "Restaurant Owner",
                    company: "Manchester Dining Co.",
                    location: "Manchester, England",
                    rating: 5,
                    testimonial: "Absolutely fantastic! Fatema helped us become the #1 restaurant in Manchester for local searches. Our reservations increased by 350% and we've opened 4 new locations across Greater Manchester. Her knowledge of British dining culture and local search behaviour is spot on. Best investment we've ever made!",
                    results: ["350% reservations", "4 new locations", "#1 Manchester ranking"],
                    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Oliver Harris",
                    title: "Professional Services Director",
                    company: "Oxford Consultancy",
                    location: "Oxford, England",
                    rating: 5,
                    testimonial: "Exceptional service! In Oxford's highly educated and competitive market, Fatema got us ranking for the most valuable keywords. Our client consultations increased by 290% and we've expanded our services across the Home Counties. Her strategic approach and deep UK market knowledge are unparalleled.",
                    results: ["290% consultations", "Home Counties expansion", "Premium positioning"],
                    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Charlotte Davies",
                    title: "Retail Manager",
                    company: "Liverpool Fashion House",
                    location: "Liverpool, England",
                    rating: 5,
                    testimonial: "Amazing results! Our fashion retail business went from being invisible online to dominating Liverpool's fashion scene. Online sales increased by 320% and our store footfall doubled. Fatema's understanding of British fashion trends and local shopping behaviours is remarkable. Couldn't be happier!",
                    results: ["320% online sales", "Doubled footfall", "Fashion scene dominance"],
                    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Thomas Brown",
                    title: "Dental Practice Owner",
                    company: "Edinburgh Dental Care",
                    location: "Edinburgh, Scotland",
                    rating: 5,
                    testimonial: "Superb work! Our dental practice was struggling to attract patients in competitive Edinburgh. Fatema's local SEO strategy brought us 270% more patient appointments and we're now the top-rated dental practice in the city. Her attention to detail and results-driven approach are outstanding.",
                    results: ["270% appointments", "Top-rated practice", "City-wide recognition"],
                    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  }
                ].map((testimonial, index) => (
                  <Card key={index} className="p-8 hover-lift">
                    <CardContent className="p-0">
                      <div className="flex items-center mb-6">
                        <img 
                          src={testimonial.image} 
                          alt={testimonial.name}
                          className="w-16 h-16 rounded-full object-cover mr-4"
                          data-testid={`img-uk-testimonial-${index}`}
                        />
                        <div>
                          <div className="font-semibold text-lg" data-testid={`text-uk-testimonial-${index}-name`}>
                            {testimonial.name}
                          </div>
                          <div className="text-sm text-gray-600" data-testid={`text-uk-testimonial-${index}-title`}>
                            {testimonial.title}
                          </div>
                          <div className="text-sm text-seo-primary font-semibold" data-testid={`text-uk-testimonial-${index}-company`}>
                            {testimonial.company}
                          </div>
                          <div className="text-xs text-gray-500" data-testid={`text-uk-testimonial-${index}-location`}>
                            <i className="fas fa-map-marker-alt mr-1"></i>
                            {testimonial.location}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex text-yellow-400 mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <i key={i} className="fas fa-star"></i>
                        ))}
                      </div>
                      
                      <p className="text-gray-600 italic mb-6 leading-relaxed" data-testid={`text-uk-testimonial-${index}-content`}>
                        "{testimonial.testimonial}"
                      </p>
                      
                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-2 text-seo-secondary">Key Results:</h4>
                        <div className="flex flex-wrap gap-2">
                          {testimonial.results.map((result, resultIndex) => (
                            <span 
                              key={resultIndex}
                              className="bg-seo-gray-50 text-seo-primary px-3 py-1 rounded-full text-sm font-semibold"
                              data-testid={`text-uk-testimonial-${index}-result-${resultIndex}`}
                            >
                              {result}
                            </span>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Italy Testimonials */}
            <TabsContent value="italy" data-testid="tab-content-testimonials-italy">
              <div className="grid lg:grid-cols-2 gap-8">
                {[
                  {
                    name: "Giuseppe Rossi",
                    title: "Boutique Owner",
                    company: "Milano Fashion House",
                    location: "Milano, Italy",
                    rating: 5,
                    testimonial: "Fantastico! Fatema understood the Italian market perfectly. Our online sales increased by 250% and we're now the top-ranked fashion boutique in Milan for local searches. La sua comprensione della cultura italiana e del comportamento dei consumatori è eccezionale. Servizio eccellente!",
                    results: ["250% online sales", "Top Milan ranking", "Cultural expertise"],
                    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Maria Bianchi",
                    title: "Restaurant Owner",
                    company: "Roma Tradizionale",
                    location: "Roma, Italy",
                    rating: 5,
                    testimonial: "Incredibile! Our restaurant group now dominates local search in Rome. Reservations increased by 380%, and we've opened 5 new locations across Lazio. Fatema capisce davvero il mercato italiano e l'industria della ristorazione. Un lavoro straordinario!",
                    results: ["380% reservations", "5 new locations", "Lazio expansion"],
                    image: "https://images.unsplash.com/photo-1494790108755-2616c0763c7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Antonio Ferrari",
                    title: "Tourism Director",
                    company: "Tuscany Experience",
                    location: "Firenze, Italy",
                    rating: 5,
                    testimonial: "Eccezionale! Our tourism business now ranks #1 for Florence attractions. Tourist bookings increased by 290% and we've expanded to Venice and Rome tours. Fatema's multi-language SEO expertise and understanding of international tourism is phenomenal. Highly recommended for Italian businesses!",
                    results: ["290% bookings", "Venice & Rome expansion", "#1 Florence attractions"],
                    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Francesca Conti",
                    title: "Professional Services Manager",
                    company: "Napoli Business Solutions",
                    location: "Napoli, Italy",
                    rating: 5,
                    testimonial: "Risultati straordinari! Our professional services firm in Naples achieved incredible growth thanks to Fatema's expertise. Client consultations increased by 270% and we now serve the entire Campania region. Her strategic approach to Italian business culture and SEO is unmatched.",
                    results: ["270% consultations", "Campania region coverage", "Strategic excellence"],
                    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Lorenzo Martini",
                    title: "Healthcare Administrator",
                    company: "Bologna Medical Center",
                    location: "Bologna, Italy",
                    rating: 5,
                    testimonial: "Perfetto! Our medical center in Bologna was struggling with online visibility. Fatema's Italian healthcare SEO strategy brought us 260% more patient appointments and we're now the leading medical facility in Emilia-Romagna. Un servizio professionale eccezionale!",
                    results: ["260% appointments", "Emilia-Romagna leadership", "Medical SEO mastery"],
                    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  },
                  {
                    name: "Giulia Romano",
                    title: "Retail Director",
                    company: "Torino Luxury Goods",
                    location: "Torino, Italy",
                    rating: 5,
                    testimonial: "Magnifico! Our luxury retail business in Turin transformed completely with Fatema's SEO expertise. Online sales grew by 310% and our store became the destination for luxury shoppers in Piedmont. Her understanding of Italian luxury market dynamics is exceptional. Highly recommended!",
                    results: ["310% online sales", "Piedmont destination", "Luxury market mastery"],
                    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"
                  }
                ].map((testimonial, index) => (
                  <Card key={index} className="p-8 hover-lift">
                    <CardContent className="p-0">
                      <div className="flex items-center mb-6">
                        <img 
                          src={testimonial.image} 
                          alt={testimonial.name}
                          className="w-16 h-16 rounded-full object-cover mr-4"
                          data-testid={`img-italy-testimonial-${index}`}
                        />
                        <div>
                          <div className="font-semibold text-lg" data-testid={`text-italy-testimonial-${index}-name`}>
                            {testimonial.name}
                          </div>
                          <div className="text-sm text-gray-600" data-testid={`text-italy-testimonial-${index}-title`}>
                            {testimonial.title}
                          </div>
                          <div className="text-sm text-seo-primary font-semibold" data-testid={`text-italy-testimonial-${index}-company`}>
                            {testimonial.company}
                          </div>
                          <div className="text-xs text-gray-500" data-testid={`text-italy-testimonial-${index}-location`}>
                            <i className="fas fa-map-marker-alt mr-1"></i>
                            {testimonial.location}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex text-yellow-400 mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <i key={i} className="fas fa-star"></i>
                        ))}
                      </div>
                      
                      <p className="text-gray-600 italic mb-6 leading-relaxed" data-testid={`text-italy-testimonial-${index}-content`}>
                        "{testimonial.testimonial}"
                      </p>
                      
                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-2 text-seo-secondary">Risultati Chiave:</h4>
                        <div className="flex flex-wrap gap-2">
                          {testimonial.results.map((result, resultIndex) => (
                            <span 
                              key={resultIndex}
                              className="bg-seo-gray-50 text-seo-primary px-3 py-1 rounded-full text-sm font-semibold"
                              data-testid={`text-italy-testimonial-${index}-result-${resultIndex}`}
                            >
                              {result}
                            </span>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Video Testimonials Section */}
      <section className="py-20 bg-white" data-testid="section-video-testimonials">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-4xl mb-6 text-gray-900" data-testid="text-video-testimonials-title">
              What Makes Clients <span className="text-seo-primary">Choose Me</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-video-testimonials-description">
              The key qualities and results that consistently earn client satisfaction and referrals
            </p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                title: "Proven Results",
                description: "Consistent delivery of 200-400% traffic increases and top rankings across all markets",
                icon: "fas fa-chart-line",
                color: "bg-seo-primary"
              },
              {
                title: "Cultural Understanding",
                description: "Deep knowledge of local markets, consumer behavior, and regional business dynamics",
                icon: "fas fa-globe",
                color: "bg-seo-secondary"
              },
              {
                title: "Transparent Communication",
                description: "Clear reporting, regular updates, and honest assessment of opportunities and challenges",
                icon: "fas fa-comments",
                color: "bg-seo-accent"
              },
              {
                title: "Long-term Partnership",
                description: "95% client retention rate with ongoing optimization and strategy refinement",
                icon: "fas fa-handshake",
                color: "bg-purple-600"
              },
              {
                title: "Industry Expertise",
                description: "Specialized knowledge across healthcare, legal, retail, restaurants, and professional services",
                icon: "fas fa-graduation-cap",
                color: "bg-pink-600"
              },
              {
                title: "Rapid Response",
                description: "24-hour response guarantee with dedicated support throughout the entire SEO journey",
                icon: "fas fa-clock",
                color: "bg-orange-500"
              }
            ].map((quality, index) => (
              <Card key={index} className="text-center p-8 hover-lift">
                <CardContent className="p-0">
                  <div className={`${quality.color} text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6`}>
                    <i className={`${quality.icon} text-2xl`}></i>
                  </div>
                  <h3 className="font-poppins font-semibold text-xl mb-4" data-testid={`text-quality-${index}-title`}>
                    {quality.title}
                  </h3>
                  <p className="text-gray-600" data-testid={`text-quality-${index}-description`}>
                    {quality.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white text-center" data-testid="section-testimonials-cta">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins font-bold text-4xl mb-6" data-testid="text-testimonials-cta-title">
            Ready to Join My Success Stories?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto" data-testid="text-testimonials-cta-description">
            Experience the same exceptional results and personalized service that has earned 98% client satisfaction
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button className="bg-seo-secondary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-600 transition-colors" data-testid="button-testimonials-cta-contact">
                <i className="fas fa-rocket mr-2"></i>
                Start Your Success Story
              </Button>
            </Link>
            <Link href="/portfolio">
              <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-seo-primary transition-colors" data-testid="button-testimonials-cta-portfolio">
                <i className="fas fa-eye mr-2"></i>
                View Portfolio
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
